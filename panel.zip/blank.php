<!DOCTYPE html>
<html>

<?php
include('components/header.php');
?>
<body>
<?php
include('components/nav.php');
include("components/sidebar.php");
?>	
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-home"></span></a></li>
				<li class="active">Home</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Home</h1>
			</div>
		</div><!--/.row-->
		
		
	</div>	<!--/.main-->

<?php 
include("components/js.php");
?>

</body>

</html>
