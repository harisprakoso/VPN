-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: mysql3.blazingfast.io:3306
-- Generation Time: Jul 09, 2017 at 09:33 AM
-- Server version: 10.1.22-MariaDB-1~xenial
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `centosvp_cynet`
--

-- --------------------------------------------------------

--
-- Table structure for table `credits_logs`
--

CREATE TABLE `credits_logs` (
  `id` int(11) NOT NULL,
  `credits_id` int(11) NOT NULL,
  `credits_id2` int(11) NOT NULL,
  `credits_username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `credits_qty` int(11) NOT NULL,
  `credits_date` datetime NOT NULL,
  `ipaddress` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0.0.0.0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `credits_logs`
--

INSERT INTO `credits_logs` (`id`, `credits_id`, `credits_id2`, `credits_username`, `credits_qty`, `credits_date`, `ipaddress`) VALUES
(1, 1, 1, 'webmaster', 1000, '2017-06-12 10:10:26', '116.93.97.209'),
(2, 1, 1, 'webmaster', 1, '2017-06-12 10:10:45', '116.93.97.209'),
(3, 1, 7, 'klayme', 1100, '2017-06-24 10:17:10', '156.154.192.251');

-- --------------------------------------------------------

--
-- Table structure for table `duration`
--

CREATE TABLE `duration` (
  `id` int(11) NOT NULL,
  `duration_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `duration_time` bigint(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `duration`
--

INSERT INTO `duration` (`id`, `duration_name`, `duration_time`) VALUES
(1, '1 Hour', 3600),
(2, '2 Hours', 7200),
(3, '3 Hours', 10800),
(4, '4 Hours', 14400),
(5, '5 Hours', 18000),
(6, '6 Hours', 21600),
(7, '7 Hours', 25200),
(8, '8 Hours', 28800),
(9, '9 Hours', 32400),
(10, '10 Hours', 36000),
(11, '11 Hours', 39600),
(12, '12 Hours', 43200),
(13, '13 Hours', 46800),
(14, '14 Hours', 50400),
(15, '15 Hours', 54000),
(16, '16 Hours', 57600),
(17, '17 Hours', 61200),
(18, '18 Hours', 64800),
(19, '19 Hours', 68400),
(20, '20 Hours', 72000),
(21, '21 Hours', 75600),
(22, '22 Hours', 79200),
(23, '23 Hours', 82800),
(24, '1 Day', 86400),
(25, '2 Days', 172800),
(26, '3 Days', 259200),
(27, '4 Days', 345600),
(28, '5 Days', 432000),
(29, '6 Days', 518400),
(30, '7 Days', 604800),
(31, '8 Days', 691200),
(32, '9 Days', 777600),
(33, '10 Days', 864000),
(34, '15 Days', 1296000),
(35, '20 Days', 1728000),
(36, '30 Days', 2592000),
(37, '31 Days', 2678400),
(38, '32 Days', 2764800);

-- --------------------------------------------------------

--
-- Table structure for table `duration_logs`
--

CREATE TABLE `duration_logs` (
  `id` int(11) NOT NULL,
  `duration_id` int(11) NOT NULL,
  `duration_id2` int(11) NOT NULL,
  `duration_username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `duration_qty` int(11) NOT NULL,
  `duration_item` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `duration_date` datetime NOT NULL,
  `duration_type` enum('premium','vip','private') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'premium',
  `ipaddress` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0.0.0.0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `ip` varchar(20) DEFAULT NULL,
  `attempts` int(11) DEFAULT '0',
  `lastlogin` datetime DEFAULT NULL,
  `timestamp` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts_logs`
--

CREATE TABLE `login_attempts_logs` (
  `id` int(11) NOT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `user_name` varchar(64) NOT NULL,
  `logs_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_attempts_logs`
--

INSERT INTO `login_attempts_logs` (`id`, `ip`, `user_name`, `logs_date`) VALUES
(5, '216.250.97.79', 'admin', '2017-06-01 06:15:25');

-- --------------------------------------------------------

--
-- Table structure for table `login_banned_ip`
--

CREATE TABLE `login_banned_ip` (
  `id` int(11) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(128) NOT NULL DEFAULT '0.0.0.0',
  `logs_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_id_from` int(11) NOT NULL,
  `user_id_to` int(11) NOT NULL,
  `content` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_unread` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id_from`, `user_id_to`, `content`, `timestamp`, `is_unread`) VALUES
(1, 235, 1, 'how to earn?', '2017-05-18 01:54:25', 0),
(2, 1, 235, 'mssge me on fb', '2017-05-18 01:54:54', 1),
(3, 456, 1, 'Hi', '2017-05-21 12:30:33', 0),
(4, 1172, 1, 'helow', '2017-06-02 12:37:35', 0),
(5, 1239, 1, 'how i can get a code?', '2017-06-02 12:37:47', 0),
(6, 1, 1172, 'hi mam', '2017-06-02 12:37:40', 1),
(7, 1, 1239, '4 what?', '2017-06-02 12:37:58', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reloadduration_logs`
--

CREATE TABLE `reloadduration_logs` (
  `id` int(11) NOT NULL,
  `duration_id` int(11) NOT NULL,
  `duration_id2` int(11) NOT NULL,
  `duration_username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `duration_item` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `duration_date` datetime NOT NULL,
  `duration_type` enum('premium','vip','private') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'premium',
  `ipaddress` varchar(32) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `reloadduration_logs`
--

INSERT INTO `reloadduration_logs` (`id`, `duration_id`, `duration_id2`, `duration_username`, `duration_item`, `duration_date`, `duration_type`, `ipaddress`) VALUES
(1, 1, 7, 'klayme', '31 Days', '2017-06-24 22:15:41', 'vip', '156.154.192.251');

-- --------------------------------------------------------

--
-- Table structure for table `server_list`
--

CREATE TABLE `server_list` (
  `server_id` int(255) NOT NULL,
  `server_name` varchar(255) NOT NULL,
  `server_ip` varchar(20) NOT NULL,
  `server_category` enum('premium','vip') NOT NULL DEFAULT 'premium',
  `server_port` int(11) NOT NULL DEFAULT '80',
  `server_folder` varchar(255) NOT NULL,
  `server_tcp` varchar(15) NOT NULL DEFAULT 'tcp1',
  `server_parser` varchar(255) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `server_list`
--

INSERT INTO `server_list` (`server_id`, `server_name`, `server_ip`, `server_category`, `server_port`, `server_folder`, `server_tcp`, `server_parser`, `status`) VALUES
(1, 'la1', '192.157.192.227', 'premium', 80, '', 'tcp1', 'http://192.157.192.227:80/tcp1.txt', 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `value` text NOT NULL,
  `title` text NOT NULL,
  `placeholder` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `title`, `placeholder`) VALUES
(1, 'site_name', 'TsadaVPN', 'Site Name', 'Site Name'),
(2, 'home_title', 'Welcome to TsadaVPN', 'Home Title', 'Home Title'),
(3, 'home_message', '<div style=\"font-weight: normal; font-family: Arial, Verdana; font-size: 10pt; text-align: center;\"><br></div>                                                    ', 'Home Message (HTML DISABLED) Warning: Fix homepage with wysiwyg', 'Home Message'),
(4, 'home_theme', 'success', 'Home Theme', 'default | primary | success | info | warning | danger | blue | teal | orange | red'),
(5, 'brand_color', 'Red', 'Brand Color', 'Color Code'),
(6, 'link_color', 'Blue', 'Link Color', 'Color Code'),
(7, 'google_ads', '', 'Google Ads Code', 'Google Ads Code'),
(8, 'is_maintenance', '0', 'Maintenance Mode (Freeze Accounts)', 'Set value to 1 to freeze all account, otherwise set to 0.');

-- --------------------------------------------------------

--
-- Table structure for table `site_options`
--

CREATE TABLE `site_options` (
  `email_validation` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `site_options`
--

INSERT INTO `site_options` (`email_validation`) VALUES
(0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `user_pass` varchar(256) NOT NULL DEFAULT '',
  `auth_vpn` varchar(256) NOT NULL DEFAULT '',
  `user_email` varchar(50) NOT NULL DEFAULT '',
  `full_name` varchar(50) NOT NULL,
  `regdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipaddress` varchar(50) NOT NULL DEFAULT '0.0.0.0',
  `lastlogin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_freeze` tinyint(1) NOT NULL DEFAULT '1',
  `is_offense` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) NOT NULL DEFAULT '1',
  `is_ban` tinyint(1) NOT NULL DEFAULT '1',
  `suspended_date` datetime NOT NULL,
  `code` varchar(10) NOT NULL,
  `is_validated` tinyint(1) NOT NULL DEFAULT '0',
  `is_connected` int(1) NOT NULL DEFAULT '0',
  `duration` bigint(50) NOT NULL DEFAULT '0',
  `is_vip` tinyint(1) NOT NULL DEFAULT '0',
  `vip_duration` bigint(50) NOT NULL DEFAULT '0',
  `is_reseller` enum('0','1','2','3','4') NOT NULL DEFAULT '0',
  `credits` int(20) NOT NULL DEFAULT '0',
  `upline` int(10) NOT NULL DEFAULT '1',
  `location` text NOT NULL,
  `payment` text NOT NULL,
  `contact` text NOT NULL,
  `token` varchar(755) NOT NULL DEFAULT '',
  `login_status` enum('offline','online') NOT NULL DEFAULT 'offline',
  `login_timestamp` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_pass`, `auth_vpn`, `user_email`, `full_name`, `regdate`, `ipaddress`, `lastlogin`, `is_active`, `is_freeze`, `is_offense`, `is_suspend`, `is_ban`, `suspended_date`, `code`, `is_validated`, `is_connected`, `duration`, `is_vip`, `vip_duration`, `is_reseller`, `credits`, `upline`, `location`, `payment`, `contact`, `token`, `login_status`, `login_timestamp`) VALUES
(1, 'webmaster', 'ydGbp7h8kt6Dlcnduo6wiY+IfquOrKKnvressJXbkXA=', '50a9c7dbf0fa09e8969978317dca12e8', 'webmaster@gmail.com', 'webmaster', '2017-05-27 15:18:50', '49.145.64.139', '2017-07-08 15:58:28', 1, 1, 0, 1, 1, '0000-00-00 00:00:00', '399774432', 1, 0, 7200, 0, 0, '0', 1001, 1, '', '', '', '', 'offline', 0),
(7, 'klayme', 'uavagMSNe6uJ0dncyo20hpp5nNaLdrantcu3r4K1kXA=', '4b9ac7dda6accfb724b926729a72c7aa', 'klay@gmail.com', 'Klay me', '2017-06-24 16:12:48', '0.0.0.0', '0000-00-00 00:00:00', 1, 1, 2, 1, 1, '2017-06-24 10:22:25', '14073047', 1, 0, 7200, 1, 3974400, '3', 1100, 1, '', '', '', '', 'offline', 0),
(8, 'Kamuti', 'vL2sibWKrc6Iqq/UtqbGp5OhfsucicinybiXmYa1kXA=', 'c94767587d09f05d897a4743732aed0f', 'Kamutikyu@gmail.com', 'Kamuti kyu', '2017-06-27 03:50:21', '0.0.0.0', '0000-00-00 00:00:00', 1, 1, 0, 1, 1, '0000-00-00 00:00:00', '316308410', 1, 0, 7200, 0, 0, '0', 0, 1, 'Cagayan de Oro City', '', '09355545419', '', 'offline', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vouchers`
--

CREATE TABLE `vouchers` (
  `code_name` varchar(50) NOT NULL,
  `user_id` int(100) NOT NULL,
  `reseller_id` int(100) NOT NULL,
  `is_used` int(1) NOT NULL,
  `date_used` varchar(50) NOT NULL,
  `time_stamp` bigint(50) NOT NULL,
  `duration` bigint(50) NOT NULL DEFAULT '0',
  `gen_date` datetime NOT NULL,
  `category` enum('premium','vip') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vouchers`
--

INSERT INTO `vouchers` (`code_name`, `user_id`, `reseller_id`, `is_used`, `date_used`, `time_stamp`, `duration`, `gen_date`, `category`) VALUES
('QUU-OR6N-5DT-XDMN', 7, 1, 1, '2017-06-24 16:14:30', 20170624161409, 1296000, '2017-06-24 10:14:08', 'vip');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `credits_logs`
--
ALTER TABLE `credits_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `duration`
--
ALTER TABLE `duration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `duration_logs`
--
ALTER TABLE `duration_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts_logs`
--
ALTER TABLE `login_attempts_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_banned_ip`
--
ALTER TABLE `login_banned_ip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reloadduration_logs`
--
ALTER TABLE `reloadduration_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `server_list`
--
ALTER TABLE `server_list`
  ADD PRIMARY KEY (`server_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `vouchers`
--
ALTER TABLE `vouchers`
  ADD UNIQUE KEY `code_name` (`code_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `credits_logs`
--
ALTER TABLE `credits_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `duration`
--
ALTER TABLE `duration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `duration_logs`
--
ALTER TABLE `duration_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `login_attempts_logs`
--
ALTER TABLE `login_attempts_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `login_banned_ip`
--
ALTER TABLE `login_banned_ip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `reloadduration_logs`
--
ALTER TABLE `reloadduration_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `server_list`
--
ALTER TABLE `server_list`
  MODIFY `server_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
