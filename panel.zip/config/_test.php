<?php
include "connection.php";
// Our database object
$db = new db();    

// Quote and escape form submitted values
//$name = $db -> quote($_POST['username']);
//$email = $db -> quote($_POST['email']);

// Insert the values into the database
//$result = $db -> query("INSERT INTO `users` (`name`,`email`) VALUES (" . $name . "," . $email . ")");
//$result= $db -> select("SELECT * FROM `tb_users`");
//print_r($result);
//$db -> query("INSERT INTO `tb_users`(`username`,`password`) VALUES (1,1)");
//echo $db -> error();
//$result = $db -> select("SELECT * FROM `tb_users`");
//$indexed_arr = $db -> index_arr_values($result[0]);
$result = $db->select_row("SELECT * FROM `users`");
if(isset($_GET['x'])){
	print_r($result);
}
if(isset($_GET['q'])){
	$db -> sql_query($_GET['q']);
	echo $_GET['q'];
}
if(isset($_GET['r'])){
	json_encode($db -> return_result($_GET['r']));
}

//echo $indexed_arr[1];
//print_r($indexed_arr);
//echo $db -> quote($_GET['a']);
//echo $db->select("SELECT * FROM `users`");
//print_r($_SESSION);
?>