<?php
ob_start();
session_start();
include_once('config.php');
$db = new db();
$variable = $db -> site_settings();
$client = $db->encryptor('encrypt', 0);
$subreseller = $db->encryptor('encrypt', 1);
$reseller = $db->encryptor('encrypt', 2);
$subadmin = $db->encryptor('encrypt', 3);
$administrator = $db->encryptor('encrypt', 4);
$premium_encrypt = base64_encode($db->encryptor('encrypt', 'premium'));
$vip_encrypt = base64_encode($db->encryptor('encrypt', 'vip'));
ob_flush();
ob_end_flush();
?>