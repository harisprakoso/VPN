<!DOCTYPE html>
<html>

<?php
include('components/header.php');
?>
<body>
<?php
include('components/nav.php');
include("components/sidebar.php");


?>	
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-cog"></span></a></li>
				<li class="active">Create Account Page</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Account Form</div>
					<div class="panel-body">
						<form id="profile_form" role="form">
							<input type="hidden" id="submitted" name="submitted" value="Register Submit" />
							<div class="col-md-6">
								<div class="form-group">
									<label>Full Name</label>
									<input class="form-control" placeholder="Enter Full Name" name="full_name" value="" required>
								</div>
								
								<div class="form-group">
									<label>Email</label>
									<input class="form-control" type="email" name="email" placeholder="email@example.com" value="" required>
								</div>
								<div class="form-group">
									<label>Location</label>
									<input class="form-control" placeholder="Enter Location" name="location" value="">
								</div>
								<div class="form-group">
									<label>Mode of Payment (Reseller)</label>
									<input class="form-control" placeholder="For Resellers" name="payment" value="">
								</div>
								<div class="form-group">
									<label>Contact Info</label>
									<input class="form-control" placeholder="Contact Info" name="contact" value="">
								</div>
								<?php 
								if(isset($_SESSION['user']))
								{ 
									
									if($_SESSION['user']['id']=='1'){
										echo '
										<div class="form-group">
											<label>User Type</label>
											<select class="form-control" name="type" required>
												<option value="'.$client.'">Client</option>
												<option value="'.$subreseller.'">Sub Reseller</option>
												<option value="'.$reseller.'">Reseller</option>
												<option value="'.$subadmin.'">Sub Administrator</option>
												<option value="'.$administrator.'">Administrator</option>
											</select>
										</div>';
									}
									elseif($_SESSION['user']['rank']=="Administrator")
									{
										echo '
										<div class="form-group">
											<label>User Type</label>
											<select class="form-control" name="type" required>
												<option value="'.$client.'">Client</option>
												<option value="'.$subreseller.'">Sub Reseller</option>
												<option value="'.$reseller.'">Reseller</option>
												<option value="'.$subadmin.'">Sub Administrator</option>
											</select>
										</div>';
									}
									elseif($_SESSION['user']['rank']=="Sub Administrator")
									{
										echo '
										<div class="form-group">
											<label>User Type</label>
											<select class="form-control" name="type" required>
												<option value="'.$client.'">Client</option>
												<option value="'.$reseller.'">Reseller</option>
											</select>
										</div>';
									}
									elseif($_SESSION['user']['rank']=="Reseller")
									{
										echo '
										<div class="form-group">
											<label>User Type</label>
											<select class="form-control" name="type" required>
												<option value="'.$client.'">Client</option>
												<option value="'.$subreseller.'">Sub Reseller</option>
											</select>
										</div>';
									}else{
										echo '<input type="hidden" id="type" name="type" value="'.$client.'" required />';
									}
								}
								?>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Username</label>
									<input id="username" class="form-control" name="username" type="text" placeholder="Username" required>
								
								</div>
								<div class="form-group">
									<label>Password</label>
									<input id="password" class="form-control" name="password" type="password" placeholder="Password" required>
								
								</div>
																
								<div class="form-group">
									<label>Confirm Password</label>
									<input id="password_two" class="form-control" name="password_two" type="password" placeholder="Verify Password" required>
								</div>
								<button type="submit" id="submitReg" name="submitReg" class="btn btn-primary">Create Account</button>
								<div id="success"></div>
							</div>
						</form>	
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
		
		
	</div>	<!--/.main-->

<?php 
include("components/js.php");
?>
<script>
$('document').ready(function(){
	var $form  = $("#profile_form");
	$form.ajaxForm({
		url: "app/account/create_account.php", 
		data: $('#profile_form').serialize(), 
		type: "POST",
		cache: false,
		success: function (result)
		{
			$('#success').html(result);
			$form[0].reset();
			setTimeout(function () { $('.close').trigger('click'); }, 3000);
		}
	});
});

</script>
	
</body>

</html>
