<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
?>
<!DOCTYPE html>
<html>

<?php
require DOC_ROOT_PATH . './components/header.php';
?>
<body>
<?php
require DOC_ROOT_PATH . './app/chkToken.php';
require DOC_ROOT_PATH . './components/nav.php';
require DOC_ROOT_PATH . './components/sidebar.php';

if(!isset($_SESSION['user'])){
	header("location: login.php");
}
$message="";
if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank']=="Administrator"){
	if(isset($_POST['submit'])){
		foreach($_POST as $key => $value){
			$db -> sql_query("UPDATE `settings` SET `value`='". $db -> escape(($value)) ."' WHERE `name`='".$db -> escape($key)."'");
			//echo($data);
			//echo $key .":".$value;
		}
		$message="<div class='alert bg-success'role='alert' id='error-alert'>
									<span class='glyphicon glyphicon-exclamation-sign'></span><span id='alert-message2'> Site Updated</span></a>
								</div>";
	}
}else{
	header("location: index.php");
}
$variable= $db -> site_settings();


?>	
<style>
a, a:hover, a:focus{
	color: <?php echo $variable['link_color'];?>;
}
.navbar-brand span {
    color: <?php echo $variable['brand_color'];?> !important;
}
</style>
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-wrench"></span></a></li>
				<li class="active">Site Config</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Settings</h1>
			</div>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Variables Configuration</div>
					<div class="panel-body">
						<div class="col-md-12">
							<form id="site_config" role="form" method="POST">
								<?php
								$get_variable = $db -> return_result("SELECT * FROM `settings`");
								foreach($get_variable as $setting){
									echo "<div class='form-group'>";
									echo "	<label>{$setting['title']}</label>";
									echo "	<input class='form-control' name=\"".htmlspecialchars($setting['name'])."\" placeholder=\"".($setting['placeholder'])."\" value=\"".htmlspecialchars($setting['value'])."\">";
									echo "</div>";
								}
								?>
								<input type="submit" name="submit" class="btn btn-primary btn-block"></input>
						<br />
						<br />
						<?php echo $message;?>
						</div>
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
		
		
	</div>	<!--/.main-->

<?php 
require DOC_ROOT_PATH . './components/js.php';
?>
	
</body>

</html>
