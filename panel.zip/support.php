<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
?>
<!DOCTYPE html>
<html>

<?php
require DOC_ROOT_PATH . './components/header.php';
?>
<body>
<?php
require DOC_ROOT_PATH . './app/chkToken.php';
require DOC_ROOT_PATH . './components/nav.php';
require DOC_ROOT_PATH . './components/sidebar.php';

$delete_message="";

if(!isset($_SESSION['user'])){
	header("location: login.php");
}
if($current_rank<>"Administrator"){
	if($_GET['id']<>$_SESSION['user']['id']){
		header("location: support.php?id=".$_SESSION['user']['id']);
	}
}

if(isset($_GET['delete'])){
	if(isset($_GET['id'])){
		if($_GET['id']<>1){
			if($_GET['delete']==0){
				if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank']=="Administrator"){
					$db -> sql_query("DELETE FROM `messages` WHERE `user_id_from`=".$db -> escape($_GET['id']));
					$db -> sql_query("DELETE FROM `messages` WHERE `user_id_to`=".$db -> escape($_GET['id']));
					header("location: support.php?delete=1");
				}else{
					$delete_message="alert('Unauthorized Action.');";
				}
			}
		}
	}
	if($_GET['delete']==1){
		$delete_message="alert('Message Deleted!');";
	}
}

?>	
<style>	
.chat .panel-body {
    overflow-y: scroll;
    height: 400px;
}
</style>	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-list-alt"></span></a></li>
				<li class="active">Contact Support</li>
			</ol>
		</div><!--/.row-->
		<?php
		$users = "";
		if(isset($_GET['user'])){
			if($_GET['user']=="subadmin"){
				$users="Sub Administrator ";
			}elseif($_GET['user']=="reseller"){
				$users="Reseller ";
			}elseif($_GET['user']=="subreseller"){
				$users="Sub Reseller ";
			}elseif($_GET['user']=="client"){
				$users="Client ";
			}elseif($_GET['user']=="seller"){
				$users="Authorized Seller ";
			}else{
				$users="All ";
			}
		}else{
			$users="All ";
		}
		?>
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Support Inbox</h1>
			</div>
		</div><!--/.row-->
		<?php
		if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank']=="Administrator" && !isset($_GET['id'])){
		?>
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Message List</div>
					<div class="panel-body">
						<table data-toggle="table" data-url="app/support/messages.php"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						    <thead>
						    <tr>
						        <!--th data-field="state" data-checkbox="true" >Item ID</th-->
						        <th data-field="user_name"  data-sortable="true">User Name</th>
						        <th data-field="full_name"  data-sortable="true">Name</th>
						        <th data-field="timestamp"  data-sortable="true">Timestamp</th>
						        <th data-field="is_unread"  data-sortable="true">Unread</th>
						        <th data-field="action" data-sortable="true">Action</th>
						    </tr>
						    </thead>
						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
		<?php
		}
		if(isset($_GET['id'])){
		?>
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default chat">
					<div class="panel-heading" id="accordion"><span class="glyphicon glyphicon-comment"></span> Chat 
					<?php if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank']=="Administrator"){?>
					<span class="pull pull-right"><a href ="support.php" class="btn btn-danger btn-md"> <span class="glyphicon glyphicon-envelope"></span>Back to inbox</a></span>
					<?php }?>
					</div>
					<div class="panel-body" id="list_convo">
						<ul id="convo">
						</ul>
					</div>
					
					<div class="panel-footer">
						<form id="chat_form">
							<div class="input-group">
								<input type="text" requ class="form-control input-md" name="message" id="content" autocomplete="off" placeholder="Type your message here..." required/>
								<input name="id" id="sender" type="hidden" value="<?php echo $db -> escape($_GET['id']);?>" />
								<span class="input-group-btn">
									<button type="submit" class="btn btn-success btn-md" id="btn-chat">Send</button>
								</span>
							</div>
						</form>
					</div>
				
			</div><!--/.col-->
			
			
			</div>
		</div><!--/.row-->	
		<?php
		}
		?>
	</div>	<!--/.main-->

<?php 
require DOC_ROOT_PATH . './components/js.php';
?>
<style>
#scroll {
    overflow-y: scroll;
}
</style>
	<script src="js/bootstrap-table.js"></script>
</body>
<script>
function view_message(id){
	window.location="support.php?id="+id;
}


function delete_message(id){
	var r = confirm('Delete Conversation?');
	if (r == true) { 
		window.location="support.php?action=delete&id="+id+"&delete=0";
	}
}
setTimeout(function () {
	goDown();
}, 3000);

setTimeout(function () { <?php echo $delete_message;?>}, 1000);

function goDown(){
	var goBelow = $('#list_convo');
    var height = goBelow[0].scrollHeight;
    goBelow.scrollTop(height);
}

$("#chat_form").submit(function(event){
	event.preventDefault();
		$.ajax({
			url: "app/support/send.php", data: $('#chat_form').serialize(), type: "POST",  dataType: 'json',
			success: function (result) {
						console.log(result.status + " " + result.message);
						if (result.status!=1) { 
							$('#convo').append('<li class="left clearfix" ><h4><center>There was an error encountered. Please try again.</center></h4></li>');
						}else{
							getConvo($('#sender').val());
						}
					}
		});
		$('#content').val('');
		console.log('clicked');
	});


<?php
if(isset($_GET['id'])){
echo "setTimeout(function () {getConvo(".$db -> escape($_GET['id']).");}, 1000);";
?>
setInterval(function(){ getConvo($('#sender').val()); }, 10000);
var result=[];
function getConvo(id) {
	$.ajax({
		type:'GET',
		url:'app/support/convo.php',
		data: 'id='+id,
		success: function (e) {
					result = e;//JSON.parse(e);
					//console.log(result);
					$('#convo').empty();
					setMessage(result);
				}
	});
};

function setMessage(result) {
	if(result.length==0){
		$('#convo').append('<li class="left clearfix" ><h4><center>No Message</center></h4></li>');
	}
	for(x=0;x<result.length;x++){
		origin="left clearfix";
		avatar="http://placehold.it/80/30a5ff/fff?text=CSR";
		pull="left";
		if(result[x]['user_id_from']!=1){
			origin="left clearfix";
			avatar="http://placehold.it/80/dde0e6/5f6468?text=CLI";
			pull="right";
		}
		id = result[x]['id'];
		timestamp = result[x]['timestamp'];
		content = result[x]['content'];
		name = result[x]['name'] + " ["+ result[x]['from']+"] ";
		addMessage(origin,id,pull,avatar,name,timestamp,content);
		//$('#convo').append('<li class="'+origin+'" id="'+result[x]['id']+'"><span class="chat-img pull-'+pull+'"><img src="'+avatar+'" alt="User Avatar" class="img-circle" /></span><div class="chat-body clearfix"><div class="header"><strong class="primary-font">'+result[x]['name']+'</strong> <small class="text-muted">'+result[x]['timestamp']+'</small></div><p>'+result[x]['content']+'</p></div></li>');
		//console.log(result[x]['id']);
	}
    //$('#convo').append('<li class="left clearfix">');
	goDown();
}

function addMessage(origin,id,pull,avatar,name,timestamp,content){
	$('#convo').append('<li class="'+origin+'" id="'+id+'"><span class="chat-img pull-'+pull+'"><img src="'+avatar+'" alt="User Avatar" class="img-circle" /></span><div class="chat-body clearfix"><div class="header"><strong class="primary-font">'+name+'</strong> <small class="text-muted">'+timestamp+'</small></div><p>'+content+'</p></div></li>');
}
<?php
}

?>
</script>
</html>
