<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

$query = $db->sql_query("SELECT * FROM users");
while($rows = $db->sql_fetchassoc($query))
{
	$code = md5(time());
	$code = rand(0,999999999);
	
	$plain = $rows['plain'];
	$user_pass = $db->encrypt_key($db->encryptor('encrypt', $plain));
	$auth_vpn = md5($plain);
	
	$update = $db->sql_query("UPDATE users SET user_pass='".$user_pass."', auth_vpn='".$auth_vpn."', code='".$code."' WHERE user_id='".$rows['user_id']."'");
}
if($update)
{
	echo "SUCCESS!";
}else{
	echo "FAILED!";
}
?>