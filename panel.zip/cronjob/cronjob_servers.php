<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
include 'db_config.php';
$ip = get_client_ip();
if($ip == 'UNKNOWN'){
	$conn->query("DELETE FROM login_attempts WHERE attemtps>=3 AND timestamp<'".time()."'");
	$chk_server = $conn->query("SELECT * FROM server_list WHERE server_category!='proxy'");
	while($row = $chk_server->fetch_assoc())
	{
		$server_ip = $row['server_ip'];
		$server_port = $row['server_port'];
		$server_category = $row['server_category'];
		$server_parser = $row['server_parser'];
		$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		$servers = @socket_connect($server_ip, $server_port, $errno, $errstr, 30);
		if($servers)
		{
			$conn->query("UPDATE server_list SET status = 0 WHERE server_category='".$server_category."' AND server_ip='".$server_ip."'");
		}else{
			$conn->query("UPDATE server_list SET status = 1 WHERE server_category='".$server_category."' AND server_ip='".$server_ip."'");
		}
	}
}else{
	echo '<script> alert("You are a Mother Fucker! Damn shit!... Your IP Address: '.$ip.'");
	window.location.href="http://www.google.com"; </script>';
}
?>