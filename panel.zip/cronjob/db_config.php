<?php
date_default_timezone_set('Asia/Manila');

$DB_host = "localhost";
$DB_user = "officia4_userpan";
$DB_pass = '4o@nV)#hLb7R';
$DB_name = "officia4_db1";

include 'phpmailer/PHPMailerAutoload.php';
$conn = new mysqli($DB_host,$DB_user,$DB_pass,$DB_name);
if($conn->connect_error){
   die('Error : ('. $conn->connect_errno .') '. $conn->connect_error);
}

function get_client_ip() {
	$ipaddress = '';
	if (getenv('HTTP_CLIENT_IP'))
		$ipaddress = getenv('HTTP_CLIENT_IP');
	else if(getenv('HTTP_X_FORWARDED_FOR'))
		$ipaddress = getenv('HTTP_X_FORWARDED_FOR');
	else if(getenv('HTTP_X_FORWARDED'))
		$ipaddress = getenv('HTTP_X_FORWARDED');
	else if(getenv('HTTP_FORWARDED_FOR'))
		$ipaddress = getenv('HTTP_FORWARDED_FOR');
	else if(getenv('HTTP_FORWARDED'))
	   $ipaddress = getenv('HTTP_FORWARDED');
	else if(getenv('REMOTE_ADDR'))
		$ipaddress = getenv('REMOTE_ADDR');
	else
	$ipaddress = 'UNKNOWN';
	return $ipaddress;
}
?>