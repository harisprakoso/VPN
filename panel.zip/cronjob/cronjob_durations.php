<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once 'db_config.php';
$ip = get_client_ip();
if($ip == 'UNKNOWN'){
    $get = 4;
	$premium = $conn->query("UPDATE users SET duration=duration-300 WHERE user_id > 1 AND is_freeze!=0 AND is_reseller!='$get' AND duration > 0");
	$vip = $conn->query("UPDATE users SET vip_duration=vip_duration-300 WHERE  user_id > 1  AND is_freeze!=0 AND is_reseller!='$get' AND vip_duration > 0");
	$conn->query("UPDATE users SET is_reseller='$get' WHERE user_id=1");
	$conn->query("UPDATE users SET duration=0 WHERE user_id > 1 AND is_freeze!=0 AND is_reseller!='$get' AND duration < 1");
	$conn->query("UPDATE users SET is_vip=0, vip_duration=0 WHERE user_id > 1 AND is_freeze!=0 AND is_reseller!='$get' AND vip_duration < 1");
	
	if($premium){
		echo "Premium Success \n\n";
	}else{
		echo "Premium Failed \n\n";
	}
	
	if($vip){
		echo "VIP Success \n\n";
	}else{
		echo "VIP Failed \n\n";
	}
}else{
	echo '<script> alert("You are a Mother Fucker! Damn shit!... Your IP Address: '.$ip.'"); window.location.href="http://www.youjizz.com"; </script>';
}
?>

