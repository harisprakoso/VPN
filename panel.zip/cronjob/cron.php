<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('max_execution_time', 2000);

/// <<<<<<< 1ST CRONTAB SSL >>>>>  ///
/// <<<<<<<<<<<<<<>>>>>>>>>>>>>>>  ///
///  >>>> Allen Alvarez Guide >>>> ///
/// <<<<<<<<<<<<<<>>>>>>>>>>>>>>>  ///

$DB_host = 'localhost';
$DB_user = 'officia4_userpan';
$DB_pass = '4o@nV)#hLb7R';
$DB_name = 'officia4_db1';

if(getenv('HTTP_CLIENT_IP') | getenv('HTTP_X_FORWARDED_FOR') | getenv('HTTP_X_FORWARDED') | getenv('HTTP_FORWARDED_FOR') | getenv('HTTP_FORWARDED') | getenv('REMOTE_ADDR')){
	echo '<script> alert("You are a Mother Fucker! Damn shit!... Your IP Address: '.$ip.'");
	window.location.href="http://www.google.com"; </script>';exit;
}

$mysqli = new MySQLi($DB_host,$DB_user,$DB_pass,$DB_name);
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

#Delete Existing Accounts
$data1 = '';
$query1 = $mysqli->query("SELECT * FROM users WHERE user_id > 0 ORDER by user_id DESC");
if($query1->num_rows > 0)
{
	while($row1 = $query1->fetch_assoc())
	{
		$data1 .= '';
		## 7 Character Hash md5 of user_name
        $ssh_userdel = substr(base_convert(md5($row1['user_name']), 16,32), 0, 6);
        #
		$data1 .= 'userdel '.$ssh_userdel.''.PHP_EOL;
	}
}
$location1 = '/home/officia4/public_html/ssh/del.ssh.allen';
$fp1 = fopen($location1, 'w');
fwrite($fp1, $data1) or die("Unable to open file!, active.txt");
fclose($fp1);

#	REACTIVATE Accounts
$data2 = '';
$premium_active = "is_validated=1 AND is_active=1 AND is_freeze=1 AND is_suspend=1 AND duration > 0";
$vip_active = "is_validated=1 AND is_active=1 AND is_freeze=1 AND is_suspend=1 AND vip_duration > 0";
$private_active = "is_validated=1 AND is_active=1 AND is_freeze=1 AND is_suspend=1 AND private_duration > 0";

$query2 = $mysqli->query("SELECT * FROM users
WHERE ".$premium_active." AND auth_ssl!=1 OR ".$vip_active." AND auth_ssl!=1 OR ".$private_active." AND auth_ssl!=1 ORDER by user_id DESC");

if($query2->num_rows > 0)
{
	while($row2 = $query2->fetch_assoc())
	{
		$data2 .= '';
        $ssh_user = substr(base_convert(md5($row2['user_name']), 16,32), 0, 6);
        #
		$ssh_pass = $row2['auth_ssl'];
		$data2 .= 'useradd -p $(openssl passwd -1 '.$ssh_pass.') -M '.$ssh_user.''.PHP_EOL;
	}
}
$location2 = '/home/officia4/public_html/ssh/add.ssh.allen';
$fp2 = fopen($location2, 'w');
fwrite($fp2, $data2) or die("Unable to open file!, inactive.txt");
fclose($fp2);

if($location1){
    echo "Active Users Updated</br>";
}
if($location2){
    echo "Inactive Users Updated</br>";
}
?>

