<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('max_execution_time', 2000);

/// <<<<<<< 1ST CRONTAB SSL >>>>>  ///
/// <<<<<<<<<<<<<<>>>>>>>>>>>>>>>  ///
///  >>>> Allen Alvarez Guide >>>> ///
/// <<<<<<<<<<<<<<>>>>>>>>>>>>>>>  ///

$DB_host = 'localhost';
$DB_user = 'officia4_userpan';
$DB_pass = '4o@nV)#hLb7R';
$DB_name = 'officia4_db1';

$mysqli = new MySQLi($DB_host,$DB_user,$DB_pass,$DB_name);
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

$data = '';
#Active Accounts
$premium_active = "auth_ssl !=1 AND is_validated=1 AND is_active=1 AND is_freeze=1 AND is_suspend=1 AND duration > 0";
$vip_active = "auth_ssl !=1 AND is_validated=1 AND is_active=1 AND is_freeze=1 AND is_suspend=1 AND vip_duration > 0";

$private_active = "auth_ssl !=1 AND is_validated=1 AND is_active=1 AND is_freeze=1 AND is_suspend=1 AND private_duration > 0";

$query = $mysqli->query("SELECT * FROM `users` 
WHERE ".$vip_active." OR ".$private_active." ORDER by user_id DESC");
if($query->num_rows > 0)
{
	while($row = $query->fetch_assoc())
	{
		$data .= '';
		$username = $row['user_name'];
		$password = $row['auth_ssl'];
		$data .= 'useradd -p $(openssl passwd -1 '.$password.') -M '.$username.''.PHP_EOL;
	}
}
$location = '/home/officia4/public_html/ssl/active.txt';
$fp = fopen($location, 'w');
fwrite($fp, $data) or die("Unable to open file Active.txt!");
fclose($fp);

#In-Active and Invalid Accounts
$data2 = '';
$premium_deactived = "is_active=1 AND duration <= 0";
$vip_deactived = "is_active=1 AND vip_duration <= 0";
$private_deactived = "is_active=1 AND private_duration <= 0";
$is_validated = "is_validated=0";
$is_activate = "is_active=0";
$freeze = "is_freeze=0";
$suspend = "is_suspend=0";

$query2 = $mysqli->query("SELECT * FROM users 
WHERE ".$is_validated." OR ".$is_activate." OR ".$freeze." OR ".$suspend." OR  ".$premium_deactived ." AND ".$vip_deactived." AND ".$private_deactived."
");
if($query2->num_rows > 0)
{
	while($row2 = $query2->fetch_assoc())
	{
		$data2 .= '';
		$toadd = $row2['user_name'];	
		$data2 .= 'userdel '.$toadd.''.PHP_EOL;
	}
}

$location2 = '/home/officia4/public_html/ssl/not-active.txt';
$fp = fopen($location2, 'w');
fwrite($fp, $data2) or die("Unable to open file! Not Active.txt");
fclose($fp);

$mysqli->close();

if($location){
    echo "Active Users Updated";
}
if($location2){
    echo "Inactive Users Updated";
}
?>












