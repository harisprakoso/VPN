<!DOCTYPE html>
<html>

<?php
include('components/header.php');
?>
<body>
<?php
include('components/nav.php');
include("components/sidebar.php");

if(isset($_SESSION['user'])){
	header("location: index.php");
}
?>	
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-log-in"></span></a></li>
				<li class="active">Login Page</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading text-center">Login Account</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form id="chkLogin" action="" method="post" accept-charset="UTF-8" role="form">
								<input type='hidden' name='submitted' id='submitted' value='Check Login'>
								<input type='hidden' name='CSRFtoken' id='CSRFtoken' value='<?php echo $db->CSRFtoken(); ?>'>
								<div class="form-group">
									<label class="sr-only" for="username">Username</label>
									<input class="form-control" id='username' name="username" type="text" 
									value='' placeholder="username" required autocomplete="off">
								</div>
								<button type="submit" class="btn btn-primary btn-block" name="submitCheck">
									<i class="glyphicon glyphicon-log-in"></i> Next
								</button>
							</form>

							<form id="login" class="hidden" disabled="disabled" method="post" accept-charset="UTF-8" role="form">
								<div id="get_user"></div>
								<div class="form-group">
									<div class="input-group">
									<label class="sr-only" for="signin_password">Password</label>
									<input class="form-control" id='signin_password' name='signin_password' type="password"
									placeholder="Password" required autocomplete="off">
									<a class="input-group-addon" href="javascript:void(0);" onclick="toggle_password('signin_password');" id="showhide"><i class="glyphicon glyphicon-eye-open"></i></a>
									</div>
								</div>
								<div class="form-group">
									<label class="sr-only" for="signin_username">Username</label>
									<input class="form-control" id='signin_username' name="signin_username" type="hidden" 
									value='' placeholder="Username" required autocomplete="off">
								</div>
								<input type='hidden' name='CSRFtoken' id='CSRFtoken' value='<?php echo $db->CSRFtoken(); ?>'>
								<input type='hidden' name='submitted' id='submitted' value='Login'>
								<button type="submit" class="btn btn-primary btn-block" name="submitLogin">
									<i class="glyphicon glyphicon-log-in"></i> Sign-in
								</button>
							</form>
						</div>
						
						<div class="col-md-6">
							<div class="text-center" id="loader"></div>
							<div id="success"></div>
							<p>
								<h3 class="text-center">Welcome to Official-VPN</h3>
								<h5 class="text-center">Powered by: <font color="green">
								<a href="https://www.facebook.com/OwnerEnforcervpn" target="_blank">Benny Bungcaras</a></font></h5>
							</p>
						</div>
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->

	</div>	<!--/.main-->
<?php include("components/js.php");?>
<script>
$('document').ready(function(){
	var loading = $('#loader');
	
	var $chkForm = $('#chkLogin');
	$chkForm.ajaxForm({
		type: "POST",
		url: "app/login/chkLogin.php",
		data: $chkForm.serialize(),
		dataType: "JSON",
		cache: false,
		beforeSend: function() {
			loading.html('Please! wait... While Checking Username');
		},
		error: function(jqXHR, textStatus, errorThrown) {
			$('#success').html(data);
		},
		success: function(data){
			if(data.status == 1)
			{
				$('#login').prop('disabled',false).removeClass("hidden");
				$('#signin_username').val(data.message);
				$('#get_user').html(data.username);
				$chkForm.prop('disabled',true).addClass("hidden");
			}else{
				$('#success').html(data.message);
				$('#login').prop('disabled',true).addClass("hidden");
				setTimeout(function () { $('.close').trigger('click'); }, 3000);
			}
		},
		complete: function(){
			loading.html('');
		}
	});
		
	var $form = $('#login');
	$form.ajaxForm({
		type: "POST",
		url: "app/login/userLogin.php",
		data: $form.serialize(),
		beforeSend: function() {
			loading.html('Please! wait... While Validating your Account!...');
		},
		error: function(jqXHR, textStatus, errorThrown) {
			$('#success').html(data);
			setTimeout(function () { $('.close').trigger('click'); }, 3000);
		},
		success: function(data){
			$('#success').html(data);
		},
		complete: function(){
			loading.html('');
		}
	});	
});
	
function toggle_password(target){
    var d = document;
    var tag = d.getElementById(target);
    var tag2 = d.getElementById("showhide");

    if (tag2.innerHTML == '<i class="glyphicon glyphicon-eye-open"></i>')
	{
        tag.setAttribute('type', 'text');   
        tag2.innerHTML = '<i class="glyphicon glyphicon-eye-close"></i>';

    } else {
        tag.setAttribute('type', 'password');   
        tag2.innerHTML = '<i class="glyphicon glyphicon-eye-open"></i>';
    }
}
</script>
</body>

</html>
