<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator" || $_SESSION['user']['rank']=="Sub Administrator"){}else{header("location: ".$db->base_url()."users.php?user=seller");}

if(!isset($_POST['server_id']) || empty($_POST['server_id']))
{
	echo '<script> alert("Invalid Transaction"); </script>';
	header("location: users.php?user=seller");
	exit;
}else{
	
	$chk_qry = $db->sql_query("DELETE FROM server_list WHERE server_id='".$_POST['server_id']."'");
	
	if($chk_qry)
	{
		$db->HandleSuccess('Successfully! Deleted Credits!...');
	}else{
		$db->HandleError('Sorry! Delete Credits is Failed!');
	}
	echo $db->GetSuccessMessage();
	echo $db->GetErrorMessage();
}
?>
