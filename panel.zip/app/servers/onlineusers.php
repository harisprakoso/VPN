<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
ini_set('max_execution_time', 150);
$data = array();
$values = array();
$chk_servers = $db->sql_query("SELECT * FROM server_list WHERE status=1 ORDER BY server_name ASC");
while($row = $db->sql_fetchassoc($chk_servers))
{	
	$servers = @fsockopen($row['server_ip'], $row['server_port'], $errno, $errstr, 2);
	$logs = $db->openvpnLogs($row['server_parser']);
	foreach($logs['users'] as $user)
	{
		if($user['CommonName'] == 'UNDEF'){
			$CommonName = $user['CommonName'];
		}else{
			$CommonName = $user['CommonName'];
		}

		if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator" || $_SESSION['user']['rank']=="Sub Administrator"){
			$RealAddress = $user['RealAddress'];
		}
		$BytesReceived = $db->sizeformat($user['BytesSent']);
		$BytesSent = $db->sizeformat($user['BytesReceived']);
		$Since = $user['Since'];
		$values = array('CommonName' => $CommonName,
		'BytesReceived' => $BytesReceived, 
		'RealAddress' => $RealAddress, 
		'BytesSent' => $BytesSent, 
		'Since' => $Since,
		'server_name' => $row['server_name']);
		array_push($data, $values);
	}
}
echo json_encode($data);
?>
