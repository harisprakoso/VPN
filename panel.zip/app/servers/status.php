<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller"){
    
}else{
    header("location: ".$db->base_url()."users.php?user=seller");
}
$data = array();
$values = array();
$servers = $db->sql_query("SELECT * FROM server_list");
while($row = $db->sql_fetchassoc($servers))
{
	$values['server_id'] = $row['server_id'];
	$values['server_name'] = $row['server_name'];
	$values['server_ip'] = $row['server_ip'];
	$values['server_category'] = $row['server_category'];
	$values['server_port'] = $row['server_port'];
	$values['server_folder'] = $row['server_folder'];
	$values['server_tcp'] = $row['server_tcp'];
	$values['server_parser'] = $row['server_parser'];
	$values['server_status'] = $row['status'];
	
	if($row['server_category'] == 'premium'){
		$values['category'] = 'Premium';
	}else{
		$values['category'] = 'VIP';
	}
	
	if($row['status'] == 1){
		$values['status'] = '<span class="label label-success">Online</span>';
	}else{
		$values['status'] = '<span class="label label-danger">Offline</span>';
	}
	
	$values['action'] = '<button class="btn btn-info" onclick="edit('.$row['server_id'].')">Edit Server</button> <button class="btn btn-info" onclick="delete_records('.$row['server_id'].')">Delete Server</button>';
	array_push($data, $values);
}

echo json_encode($data);

?>