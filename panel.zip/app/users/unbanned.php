<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller")
{
	if(isset($_POST['id']))
	{
		$id = $db->Sanitize($_POST['id']);
		if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator")
		{
			$update = $db->sql_query("UPDATE users SET is_suspend=1, is_active=1, is_ban=1, is_offense=0 WHERE user_id='".$id."' AND is_ban=0");
		}else{
			$update = $db->sql_query("UPDATE users SET is_suspend=1, is_active=1, is_ban=1, is_offense=0 WHERE user_id='".$id."' AND is_ban=0 AND upline='".$_SESSION['user']['id']."'");
		}
		
		if($update)
		{
			echo '<script> alert("Successfully! Unbanned..."); window.location.reload(true);</script>';
		}else{
			echo '<script> alert("Successfully! Unbanned...");</script>';
		}
	}else{
		header("location: users.php?user=seller");
	}
}else{
	header("location: users.php?user=seller");
}
?>