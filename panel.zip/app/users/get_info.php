<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller")
{
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
if(!isset($_GET['uid']) && !isset($_GET['ucode']) && empty($_GET['uid']) || empty($_GET['ucode'])){
	header("location: ".$db->base_url()."users.php?user=seller");
}else{
	$uid = $db->Sanitize($_GET['uid']);
	$ucode = $db->Sanitize($_GET['ucode']);
	$qry = $db->sql_query("SELECT * FROM users WHERE user_id!=1 AND user_id='".$db->SanitizeForSQL($uid)."' AND code='".$db->SanitizeForSQL($ucode)."' LIMIT 1");
	$row = $db->sql_fetchassoc($qry);
	$values = array();	
	if($row){	
		$dur = $db->calc_time($row['duration']);

		$pdays = $dur['days'] . " days";
		$phours = $dur['hours'] . " hours";
		$pminutes = $dur['minutes'] . " minutes";
		$pseconds = $dur['seconds'] . " seconds";
		if($row['duration'] <= 0){
			$premuim_duration = "<font color='red'>Not Active</font>";
		}else{
			$premuim_duration = strtotime($pdays . $phours . $pminutes . $pseconds);
			$premuim_duration = date('F d, Y h:i:s A', $premuim_duration);
		}

		$dur2 = $db->calc_time($row['vip_duration']);

		$vdays = $dur2['days'] . " days";
		$vhours = $dur2['hours'] . " hours";
		$vminutes = $dur2['minutes'] . " minutes";
		$vseconds = $dur2['seconds'] . " seconds";
		if($row['vip_duration'] <= 0){
			$vip_duration = "<font color='red'>Not Active</font>";
		}else{
			$vip_duration = strtotime($vdays . $vhours . $vminutes . $vseconds);
			$vip_duration = date('F d, Y h:i:s A', $vip_duration);
		}
		
		$user_pass = $db->decrypt_key($row['user_pass']);
		$user_pass = $db->encryptor('decrypt',$user_pass);
		$values['username'] = $row['user_name'];
		$values['password'] = $user_pass;
		$values['fullname'] = $row['full_name'];
		$values['email'] = $row['user_email'];
		$values['status'] = $row['is_active'];
		$values['regdate'] = date('F d, Y h:i:s', strtotime($row['regdate']));
		$values['lastlogin'] = date('F d, Y h:i:s', strtotime($row['lastlogin']));
		$values['ipaddress'] = $row['ipaddress'];
		$values['premiumduration'] = $row['duration'];
		$values['premiumdate'] = $premuim_duration;
		$values['vipduration'] = $row['vip_duration'];
		$values['vipdate'] = $vip_duration;
	}
	echo json_encode($values);	
}
?>