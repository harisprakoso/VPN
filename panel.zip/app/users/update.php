<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';
$time = time();
$active = $time + 1800;
if(!isset($_SESSION['user'])){
	header("location: ".$db->base_url()."users.php?user=seller");
}else{	
	$db->checkToken($_SESSION['user']['id']);
	$db->sql_query("UPDATE users SET token='', login_status='offline', login_timestamp=0 WHERE login_timestamp<$time");
}
?>