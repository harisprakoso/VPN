<?php
header('Content-Type: application/json');
include_once("../../config/connection.php");

$get_type="";
$actions="'N/A'";

if(isset($_GET['user']))
{
	switch($_GET['user'])
	{
		case "seller":
			if(isset($_SESSION['user']))
			{
				if($_SESSION['user']['rank']=="Client"){
					$get_type ="  AND `user_id`!='".$_SESSION['user']['id']."' AND `is_reseller`>1 AND is_reseller!=5 ";
					$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
				}
			}
			$get_type ="  AND is_reseller>1 AND is_reseller!=5 ";			
			break;
		case "subadmin":
			$get_types =" AND `is_reseller`!=0 AND `is_reseller`!=1 AND `is_reseller`!=2 AND `is_reseller`!=3 AND `is_reseller`=4 ";
			if(isset($_SESSION['user']))
			{
				if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator"){
					$get_type = $get_types."  AND `user_id`!='".$_SESSION['user']['id']."'";
				}
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
			}else{
				$get_type = $get_types." AND `user_id`!='".$_SESSION['user']['id']."' AND `upline`='".$_SESSION['user']['id']."'";
			}
			//$get_type="AND `is_reseller`=3 ";
			//$actions = "CONCAT(CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`),'\')\">View</button>')";
			break;
		case "reseller":
			$get_types =" AND `is_reseller`=3 AND `is_reseller`!=0 AND `is_reseller`!=1 AND `is_reseller`!=2 ";
			if(isset($_SESSION['user'])){
				if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator"){
					$get_type = $get_types;
				}
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
				
				if($_SESSION['user']['rank']=="Sub Administrator" || $_SESSION['user']['rank']=="Reseller"){
					$get_type = $get_types."  AND `user_id`!='".$_SESSION['user']['id']."' AND `upline`='".$_SESSION['user']['id']."'";
					//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
					$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
				}
				
			}else{
				$get_type = $get_types." AND `user_id`!='".$_SESSION['user']['id']."'";
			}
			//$get_type="AND `is_reseller`=2 ";
			//$actions = "CONCAT(CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`),'\')\">View</button>')";
			break;
		case "subreseller":
			$get_types = " AND `is_reseller`!=0 AND `is_reseller`!=1 AND `is_reseller`=2 AND `is_reseller`!=3 AND `is_reseller`!=4 AND `is_reseller`!=5 ";
			if(isset($_SESSION['user'])){
				if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator"){
					$get_type = $get_types;
				}
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
				if($_SESSION['user']['rank']=="Reseller" || $_SESSION['user']['rank']=="Sub Reseller"){
					$get_type = $get_types."  AND `user_id`!='".$_SESSION['user']['id']."' AND `upline`='".$_SESSION['user']['id']."' ";
					//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
					$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
				}
			}else{
				$get_type = $get_types."  AND `user_id`!='".$_SESSION['user']['id']."'";
			}
			
			//$get_type="AND `is_reseller`=1 ";
			//$actions = "CONCAT(CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`),'\')\">View</button>')";
			break;
		case "client":
			//$get_type=" AND`is_reseller`=0";
			if($_SESSION['user']['rank']=="Sub Reseller"){
				$get_type ="  AND `user_id`!='".$_SESSION['user']['id']."' AND `upline`='".$_SESSION['user']['id']."' ";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
			}
			
			if($_SESSION['user']['rank']=="Reseller"){
				$get_type ="  AND `user_id`!='".$_SESSION['user']['id']."' AND `upline`='".$_SESSION['user']['id']."' ";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
			}
			
			if($_SESSION['user']['rank']=="Sub Administrator"){
				$get_type ="  AND `user_id`!='".$_SESSION['user']['id']."' AND `upline`='".$_SESSION['user']['id']."' ";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
			}
			
			if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator"){
				$get_type ="  AND `user_id`!='".$_SESSION['user']['id']."' AND `is_reseller`<9 ";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
			}
			break;
		default:
	}
}

if(isset($_SESSION['user']['rank'])){
	if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator"){
		if(isset($_GET['user'])){
			if($_GET['user']=="subreseller" || $_GET['user']=="reseller" || $_GET['user']=="subadmin")
			{
				$monitoring = "";
				if(isset($_GET['monitor'])){
					if($_GET['monitor']==1){
						$monitoring = ", ";
					}
				}
				//$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ') ";
			}else{
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				if(isset($_GET['user'],$_GET['upline'])){
					$get_type="AND `is_reseller`>0 AND `upline`=". $db -> escape($_GET['upline']);
				}
			}
		}else{
			$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
			//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
		}
	}
	
	if($_SESSION['user']['rank']=="Sub Administrator"){
		if(isset($_GET['user'])){
			if($_GET['user']=="subadmin"){
				$monitoring = "";
				if(isset($_GET['monitor'])){
					if($_GET['monitor']==1){
						$monitoring = ", ";
					}
				}
				$actions = "'N/A'";
			}elseif($_GET['user']=="reseller"){
				//$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ') ";
			}else{
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
			}
		}else{
			$actions = "'N/A'";
		}
	}
	
	if($_SESSION['user']['rank']=="Reseller"){
		if(isset($_GET['user'])){
			if($_GET['user']=="reseller" || $_GET['user']=="subreseller"){
				$monitoring = "";
				if(isset($_GET['monitor'])){
					if($_GET['monitor']==1){
						$monitoring = ", ";
					}
				}
				$actions = "'N/A'";
			}elseif($_GET['user']=="subreseller"){
				//$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ') ";
			}else{
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
			}
		}else{
			$actions = "'N/A'";
		}
	}
	
	if($_SESSION['user']['rank']=="Sub Reseller"){
		if(isset($_GET['user'])){
			if($_GET['user']=="client"){
				$monitoring = "";
				if(isset($_GET['monitor'])){
					if($_GET['monitor']==1){
						$monitoring = ", ";
					}
				}
				$actions = "'N/A'";
			}elseif($_GET['user']=="subreseller"){
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
			}else{
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				//$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ') ";
			}
		}else{
			$actions = "'N/A'";
		}
	}
}else{
	$actions="'(Must be logged in)'";
}

//$query="SELECT `user_name`,`full_name`,IF(`is_reseller`=1,'Reseller','Client') as 'type',IF(`duration`>0,'Active','Inactive') as 'status',`payment`,`contact`,(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`upline`) as 'reseller',$actions as 'action' FROM `users` as tb1 WHERE $get_type";
$query="SELECT `user_name`,`full_name`,(CASE WHEN is_reseller=5 THEN 'Administrator' 
											 WHEN is_reseller=4 THEN 'Sub Administrator'
											 WHEN is_reseller=3 THEN 'Reseller'
											 WHEN is_reseller=2 THEN 'Sub Reseller'
											 ELSE 'Client'
										END) as 'type',
										(CASE WHEN is_freeze=0 THEN '<label class=\"label label-info\">Freezed</label>'
											  WHEN is_suspend=0 AND is_ban=1 THEN '<label class=\"label label-warning\">Suspended</label>'
											  WHEN is_offense>=2 THEN '<label class=\"label label-danger\">Banned</label>'
											  ELSE '<label class=\"label label-success\">Live</label>'
										END) as stats,
										IF(`login_status`='online','<label class=\"label label-success\">Online</label>','<label class=\"label label-danger\">Offline</label>') as 'login',
										IF(`duration`>0,'<label class=\"label label-success\">Active</label>','<label class=\"label label-danger\">Inactive</label>') as 'premium_status',
										TIME_FORMAT(SEC_TO_TIME(`duration`),'%H hour(s) %i min(s)') as `duration`,
										IF(`vip_duration`>0,'<label class=\"label label-success\">Active</label>','<label class=\"label label-danger\">Inactive</label>') as 'vip_status',
										TIME_FORMAT(SEC_TO_TIME(`vip_duration`),'%H hour(s) %i min(s)') as `vip_duration`,
										`payment`,`contact`,$actions as 'action',
										`credits` 
										FROM `users` as tb1 WHERE `user_id`!=1 $get_type";
//echo $query;
echo json_encode($db -> return_result($query));
?>