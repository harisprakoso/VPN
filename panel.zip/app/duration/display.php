<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller"){
		if(!empty($_GET['term']))
		{
			if(isset($_GET['term']))
			{
				$data = array();
				$q = $db->Sanitize($_GET['term']);
				if($_SESSION['user']['id']==1 || $_SESSION['user']['rank']=="Administrator")
				{
					$chk_result = "SELECT user_name FROM users 
					WHERE 
					user_id!=1 AND UPPER(user_name) LIKE '%".$q ."%'";

				}else{
					$chk_result = "SELECT user_name FROM users 
					WHERE 
					user_id!=1 AND is_reseller!=4 
					AND UPPER(user_name) LIKE '%".$q."%' AND upline='".$_SESSION['user']['id']."'";
				}
				$result = $db->sql_query($chk_result);
				while($row = $db->sql_fetchassoc($result))
				{
					$username =  $row['user_name'];
					array_push($data, $username);
				}
				echo json_encode($data);
			}
		}else{
			echo '<script> alert("Invalid Transaction"); location.assign("'.$db->base_url().'users.php?user=seller")</script>';
			return false;
		}
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>
