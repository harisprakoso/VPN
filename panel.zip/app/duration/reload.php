<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
$values = array();
if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller")
{
	
	if(isset($_POST['submitted']))
	{
		if(!isset($_POST['user_name']) && !isset($_POST['scode']) && !isset($_POST['duration']) || empty($_POST['user_name']) || empty($_POST['scode']) || empty($_POST['duration'])){
			$db->HandleError('Sorry! you cannot transfer it!..');
			$values['status'] = 0;
		}else{
			// users 
			$u_qry = $db->sql_query("SELECT duration, vip_duration, user_id FROM users WHERE user_id = '".$_SESSION['user']['id']."'");
			$u_row = $db->sql_fetchassoc($u_qry);
			$user_id_2 = $u_row['user_id'];
			$duration_2 = $u_row['duration'];
			$vip_duration_2 = $u_row['vip_duration'];
			
			$category = $db->encryptor('decrypt', $_POST['category']);
					
			$get_dur = urldecode($_POST['duration']);
			$get_dur = $db->encryptor('decrypt',$get_dur);
			$durid = $db->Sanitize($get_dur);
			// duration
			$d_qry = $db->sql_query("SELECT * FROM duration WHERE id = '".$db->SanitizeForSQL($durid)."'");
			$d_row = $db->sql_fetchassoc($d_qry);
			$d_time = $d_row['duration_time'];
			$d_name = $d_row['duration_name'];

			// users 
			$code = urldecode($_POST['scode']);
			$code = $db->encryptor('decrypt',$code);
			$uid = $db->Sanitize($code);
			$uname = $db->Sanitize($_POST['user_name']);
					
			if($category == 'premium'){
				$status = 'Premium';
			}elseif($category == 'vip'){
				$status = 'VIP';
			}else{
				$db->HandleError('Sorry! Invalid Category!');
				$values['status'] = 0;
			}

			if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank'] == 'Administrator')
			{
				if($d_time > 0)
				{
					$check = $db->sql_query("SELECT user_name FROM users 
					WHERE user_id='".$db->SanitizeForSQL($uid)."' AND 
					user_name='".$db->SanitizeForSQL($uname)."'");
					if($db->sql_numrows($check) > 0)
					{
						if($category == 'premium'){
							$update = $db->sql_query("UPDATE users SET duration=duration+'".$d_time."' 
							WHERE user_id='".$db->SanitizeForSQL($uid)."' AND user_name='".$db->SanitizeForSQL($uname)."'");
						}
						elseif($category == 'vip'){
							$update = $db->sql_query("UPDATE users SET vip_duration=vip_duration+'".$d_time."' 
							WHERE user_id='".$db->SanitizeForSQL($uid)."' AND user_name='".$db->SanitizeForSQL($uname)."'");
						}

						if($update)
						{
							$db->sql_query("INSERT INTO reloadduration_logs 
							(duration_id, duration_id2, duration_username, duration_item, duration_date, duration_type, ipaddress) 
							VALUES 
							('".$user_id_2."','".$db->SanitizeForSQL($uid)."','".$uname."','".$d_name."','".date('Y-m-d H:i:s')."', '".$category."','".$_SERVER['REMOTE_ADDR']."')");
							$db->HandleSuccess('Successfully! '.$d_name.' '.$status.' Duration Reloaded to '.$uname);
							$values['status'] = 1;
						}else{
							$db->HandleError('Sorry! Reloading '.$status.' duration is Failed');
							$values['status'] = 0;
						}
					}else{
						$db->HandleError('Sorry! Reloading '.$status.' duration is Failed');
						$values['status'] = 0;
					}
				}else{
					$db->HandleError('Sorry! Invalid '.$status.' Transaction');
					$values['status'] = 0;
				}
			}
			else if($_SESSION['user']['rank'] == 'Sub Administrator' || $_SESSION['user']['rank'] == 'Reseller' || $_SESSION['user']['rank'] == 'Sub Reseller')
			{
				$check = $db->sql_query("SELECT user_name FROM users 
				WHERE user_id='".$db->SanitizeForSQL($uid)."' AND 
				user_name='".$db->SanitizeForSQL($uname)."'");
				if($db->sql_numrows($check) > 0)
				{
					if($category == 'premium')
					{
						if($duration_2 == 0)
						{
							$db->HandleError('Insufficient '.$status.' Durations!');
							$values['status'] = 0;
						}
						else
						if($duration_2 < $d_time)
						{
							$db->HandleError('Insufficient '.$status.' Durations!');
							$values['status'] = 0;
						}else{
							if($d_time > 0)
							{
								$update = $db->sql_query("UPDATE users SET duration=duration+'".$d_time."' 
								WHERE user_id='".$db->SanitizeForSQL($uid)."' AND 
								user_name='".$db->SanitizeForSQL($uname)."'");
							}
						}
					}
					elseif($category == 'vip')
					{
						if($vip_duration_2 == 0)
						{
							$db->HandleError('Insufficient '.$status.' Durations!');
							$values['status'] = 0;
						}
						else
						if($vip_duration_2 < $d_time)
						{
							$db->HandleError('Insufficient '.$status.' Durations!');
							$values['status'] = 0;
						}else{
							if($d_time > 0)
							{
								$update = $db->sql_query("UPDATE users SET vip_duration = vip_duration+'".$d_time."' 
								WHERE user_id='".$db->SanitizeForSQL($uid)."' AND 
								user_name='".$db->SanitizeForSQL($uname)."'");
							}
						}
					}else{
						$db->HandleError('Sorry! Invalid '.$status.' Transaction');
						$values['status'] = 0;
					}
					if($update)
					{
						if($category == 'premium'){
							$db->sql_query("UPDATE users SET duration = duration - '".$d_time."' 
							WHERE user_id='".$user_id_2."'");
						}
						elseif($category == 'vip'){
							$db->sql_query("UPDATE users SET vip_duration = vip_duration - '".$d_time."'
							WHERE user_id='".$user_id_2."'");
						}
						$db->sql_query("INSERT INTO reloadduration_logs 
						(duration_id, duration_id2, duration_username, duration_item, duration_date, duration_type, ipaddress) 
						VALUES 
						('".$user_id_2."','".$db->SanitizeForSQL($uid)."','".$uname."','".$d_name."','".date('Y-m-d H:i:s')."', '".$category."','".$_SERVER['REMOTE_ADDR']."')");
						$db->HandleSuccess('Successfully! '.$d_name.' '.$status.' Duration Reloaded to '.$uname);
						$values['status'] = 1;
					}else{
						$db->HandleError('Sorry! Reloading '.$status.' duration is Failed');
					}
				}else{
					$db->HandleError('Sorry! Reloading '.$status.' duration is Failed');
					$values['status'] = 0;
				}
			}
			else
			{
				$db->HandleError('Sorry! Invalid '.$status.' Transaction');
				$values['status'] = 0;
			}
		}
		$values['success'] = $db->GetSuccessMessage();
		$values['err'] = $db->GetErrorMessage();
		
		echo json_encode($values);
	}else{
		if(empty($_POST['duration'])){
			header("location: ".$db->base_url()."users.php?user=seller");
		}
		if(empty($_POST['scode'])){
			header("location: ".$db->base_url()."users.php?user=seller");
		}
		if(empty($_POST['user_name'])){
			header("location: ".$db->base_url()."users.php?user=seller");
		}
	}
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>