<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller"){
	if(!empty($_POST['type']))
	{
		$type = $_POST['type'];
		$q = $_POST['name_startsWith'];
		$data = array();
		if($_SESSION['user']['id']==1 || $_SESSION['user']['rank']=="Administrator")
		{
			$chk_result = "SELECT user_id, user_name FROM users
			WHERE 
			user_id!=1 AND UPPER($type) LIKE '%".$q ."%'";
		}else{
			$chk_result = "SELECT user_id, user_name FROM users 
			WHERE 
			user_id!=1 AND is_reseller!=4 
			AND UPPER($type) LIKE '%".$q."%' AND upline='".$_SESSION['user']['id']."'";
		}
		
		$result = $db->sql_query($chk_result);
		while($row = $db->sql_fetchassoc($result))
		{
			$username = urlencode($db->encryptor('encrypt',$row['user_id']))."|".$row['user_name'];
			array_push($data, $username);
		}
		echo json_encode($data);
	}else{
		echo '<script> alert("Invalid Transaction"); location.assign("'.$db->base_url().'users.php?user=seller")</script>';
		return false;
	}
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>
