<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller")
{
	$data = array();
	$values = array();
	$servers = $db->sql_query("SELECT * FROM duration_logs WHERE duration_id='".$_SESSION['user']['id']."'");
	while($row = $db->sql_fetchassoc($servers))
	{
		$values['username'] = $row['duration_username'];
		$values['item'] = $row['duration_item'];
		$values['qty'] = $row['duration_qty'];
		$values['date'] = date('F d, Y h:i:s', strtotime($row['duration_date']));
		
		if($row['duration_type'] == 'premium'){
			$values['category'] = 'Premium';
		}else{
			$values['category'] = 'VIP';
		}
		
		array_push($data, $values);
	}

	echo json_encode($data);
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>