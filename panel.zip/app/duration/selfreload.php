<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
$values = array();
if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller")
{
	
	if(isset($_POST['submitted']))
	{
		$code = urldecode($_POST['code']);
		$code = $db->encryptor('decrypt',$code);
		// users 
		$u_qry = $db->sql_query("SELECT user_name, credits, user_id FROM users WHERE user_id = '".$code."'");
		$u_row = $db->sql_fetchassoc($u_qry);
		$uid = $u_row['user_id'];
		$uname = $u_row['user_name'];
		$ucredits = $u_row['credits'];
		
		if($ucredits > 0)
		{
			if(!isset($_POST['qty']) && !isset($_POST['code']) && !isset($_POST['selfdurations'])
			|| empty($_POST['qty'])
			|| empty($_POST['code'])
			|| empty($_POST['selfdurations'])){
				$values['status'] = 0;
				$db->HandleError('Sorry! you cannot apply!..');
			}else{
				$category = $db->encryptor('decrypt', $_POST['category']);
				$qty = $db->Sanitize($_POST['qty']);
				$get_dur = base64_decode($_POST['selfdurations']);
				$get_dur = urldecode($get_dur);
				$get_dur = $db->encryptor('decrypt',$get_dur);
				$durid = $db->Sanitize($get_dur);
				
				// duration
				$d_qry = $db->sql_query("SELECT * FROM duration WHERE id = '".$db->SanitizeForSQL($durid)."'");
				$d_row = $db->sql_fetchassoc($d_qry);
				$d_time = $d_row['duration_time'];
				$d_name = $d_row['duration_name'];
					
				$thirtydays = 2592000;
				$fiftenndays = $thirtydays / 2;
				
				if($category == 'premium'){
					$status = 'Premium';
					if($d_time == $thirtydays){
						$d_time = $d_time * $qty;
					}else{
						$db->HandleError('Invalid Duration!');
						$values['status'] = 0;
					}
				}elseif($category == 'vip'){
					$status = 'VIP';
					if($d_time == $fiftenndays){
						$d_time = $d_time * $qty;
					}else{
						$db->HandleError('Invalid Duration!');
						$values['status'] = 0;
					}
				}else{
					$db->HandleError('Sorry! Invalid Category!');
					$values['status'] = 0;
				}
					
				$code1 = $db->generate_codes();
				$code2 = $db->generate_codes();
				$code3 = $db->generate_codes();
				$gen = $code2 . '-' . $code1 . '-' . $code3;
				$result = $db->sql_query("SELECT code_name FROM vouchers WHERE code_name='".$gen."'");
				$chk = $db->sql_fetchassoc($result);
				if($chk != 1)
				{
					if($qty > 0)
					{
						if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank'] == 'Administrator')
						{
							if($d_time > 0)
							{
								$insert = "insert into vouchers
								(code_name,
								 user_id,
								 reseller_id,
								 is_used,
								 time_stamp,
								 duration,
								 gen_date,
								 date_used,
								 category)
								values
								('".$db->SanitizeForSQL($gen)."', 
								 '".$db->SanitizeForSQL($uid)."',
								 '".$db->SanitizeForSQL($uid)."',
								 1,
								 '".time()."',
								 '".$db->SanitizeForSQL($d_time)."',
								 '".date('Y-m-d H:i:s')."',
								 '".date('Y-m-d H:i:s')."',
								 '".$category."')
								 ";
								if($db->sql_query($insert))
								{
									if($category == 'premium'){
										$db->sql_query("UPDATE users SET duration=duration+'".$d_time."' 
										WHERE user_id='".$db->SanitizeForSQL($uid)."'");
									}elseif($category == 'vip'){
										$db->sql_query("UPDATE users SET is_vip=1, vip_duration=vip_duration+'".$d_time."' 
										WHERE user_id='".$db->SanitizeForSQL($uid)."'");
									}

									$db->sql_query("INSERT INTO duration_logs 
									(duration_id, duration_id2, duration_username, duration_qty, duration_item, duration_date, duration_type, ipaddress) 
									VALUES 
									('".$db->SanitizeForSQL($uid)."','".$db->SanitizeForSQL($uid)."','".$uname."','".$qty."','".$d_name."','".date('Y-m-d H:i:s')."', '".$category."','".$_SERVER['REMOTE_ADDR']."')");
									$db->HandleSuccess('Successfully! ('.$qty.')'.$d_name.' '.$status.' Duration Reloaded.
									The generated code is '. $gen);
									$values['status'] = 1;
								}else{
									$db->HandleError('Sorry! '.$status.' Self Reload is Failed');
									$values['status'] = 0;
								}
							}else{
								$db->HandleError('Sorry! Invalid Transaction');
								$values['status'] = 0;
							}
						}
						else if($_SESSION['user']['rank'] == 'Sub Administrator' || $_SESSION['user']['rank'] == 'Reseller' || $_SESSION['user']['rank'] == 'Sub Reseller')
						{
							if($ucredits == 0)
							{
								$db->HandleError('Insufficient Credits!');
								$values['status'] = 0;
							}else
							if($ucredits < 0)
							{
								$db->HandleError('Insufficient Credits!');
								$values['status'] = 0;
							}else{
								if($d_time > 0)
								{
									$insert = "insert into vouchers
									(code_name,
									 user_id,
									 reseller_id,
									 is_used,
									 time_stamp,
									 duration,
									 gen_date,
									 date_used,
									 category)
									values
									('".$db->SanitizeForSQL($gen)."', 
									 '".$db->SanitizeForSQL($uid)."',
									 '".$db->SanitizeForSQL($uid)."',
									 1,
									 '".time()."',
									 '".$db->SanitizeForSQL($d_time)."',
									 '".date('Y-m-d H:i:s')."',
									 '".date('Y-m-d H:i:s')."',
									 '".$category."')
									 ";
									if($db->sql_query($insert))
									{
										if($category == 'premium'){
											$db->sql_query("UPDATE users SET credits = credits-'".$qty."', duration = duration+'".$d_time."' 
											WHERE user_id='".$db->SanitizeForSQL($uid)."'");
										}elseif($category == 'vip'){
											$db->sql_query("UPDATE users SET credits = credits-'".$qty."', is_vip=1, vip_duration = vip_duration+'".$d_time."' 
											WHERE user_id='".$db->SanitizeForSQL($uid)."'");
										}
										$db->sql_query("INSERT INTO duration_logs 
										(duration_id, duration_id2, duration_username, duration_qty, duration_item, duration_date, duration_type, ipaddress) 
										VALUES 
										('".$db->SanitizeForSQL($uid)."','".$db->SanitizeForSQL($uid)."','".$uname."','1','".$d_name."','".date('Y-m-d H:i:s')."', '".$category."','".$_SERVER['REMOTE_ADDR']."')");
										$db->HandleSuccess('Successfully! ('.$qty.')'.$d_name.' '.$status.' Duration Reloaded.
										The generated code is '. $gen);
										$values['status'] = 1;
									}else{
										$db->HandleError('Sorry! '.$status.' Self Reload is Failed');
										$values['status'] = 0;
									}
								}else{
									$db->HandleError('Sorry! Invalid Transaction');
									$values['status'] = 0;
								}
							}
						}else{
							$db->HandleError("Not enough credits");
							$values['status'] = 0;
						}
					}else{
						$db->HandleError('Invalid Quantity!');
						$values['status'] = 0;
					}
				}else{
					$db->HandleError('Invalid Generate!');
					$values['status'] = 0;
				}
			}
		}else{
			$db->HandleError("Not enough credits");
			$values['status'] = 0;
		}
		$values['success'] = $db->GetSuccessMessage();
		$values['err'] = $db->GetErrorMessage();
		
		echo json_encode($values);
	}else{
		if(empty($_POST['selfdurations'])){
			header("location: users.php?user=seller");
		}
		if(empty($_POST['code'])){
			header("location: users.php?user=seller");
		}
		if(empty($_POST['qty'])){
			header("location: users.php?user=seller");
		}
	}
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}

?>