<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller"){
		$chk_user = $db->sql_query("SELECT credits FROM users WHERE user_id='".$_SESSION['user']['id']."' LIMIT 1 ");
		$chk_row = $db->sql_fetchassoc($chk_user);
		if($chk_row['credits'] < 1)
		{
			$credits = 'disabled="disabled"';
		}else{
			$credits = '';
		}
		
		if($chk_row['credits'] > 0)
		{
			$credits_count = '<font style="color:blue"><b>'.$chk_row['credits'].'</b></font>';
		}else{
			$credits_count = '<font style="color:red"><b>'.$chk_row['credits'].'</b></font>';
		}
		echo
		'<button type="button" class="btn btn-success btn-block" id="applyDuration" name="applyDuration"
		onclick="selfreload()" '.$credits.'> Apply Self Reload! ~ Your Credits '.$credits_count.'</button>';
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>
