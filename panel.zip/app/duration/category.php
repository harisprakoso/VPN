<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller"){
		if(!empty($_POST['category']))
		{
			$category = $db->encryptor('decrypt', $_POST['category']);
			$duration = '';
			$result = $db->sql_query("SELECT duration, vip_duration FROM users WHERE user_id='".$_SESSION['user']['id']."' LIMIT 1");
			$row = $db->sql_fetchassoc($result);
			$duration_qry = $db->sql_query("SELECT * FROM duration ORDER BY id ASC");
			if($category == 'premium')
			{	
				while($durrows = $db->sql_fetchassoc($duration_qry))
				{
					$dur = $db->calc_time($row['duration']);
					$durs = 'Premium: '.$dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minutes";	
					$thirtydays = 2592000;
					if($durrows['duration_time'] == $thirtydays)
					{				
						$duration .= 
						'<option class="form-control" value="'.base64_encode(urlencode($db->encryptor('encrypt',$durrows['id']))).'">
						'.$durrows['duration_name'].' 
						Duration</option>';
					}
				}
			}
			else
			if($category == 'vip')
			{
				while($vipdurrows = $db->sql_fetchassoc($duration_qry))
				{
					$dur = $db->calc_time($row['vip_duration']);
					$durs = 'VIP: '.$dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minutes";
					$vipthirtydays = 2592000;
					$fithteendays = $vipthirtydays / 2;
					if($vipdurrows['duration_time'] == $fithteendays)
					{
						$duration .= 
						'<option value="'.base64_encode(urlencode($db->encryptor('encrypt',$vipdurrows['id']))).'">
						'.$vipdurrows['duration_name'].' 
						Duration</option>';
					}
				}
			}elseif($category != 'premium' || $category != 'vip'){
				echo '<script> alert("Invalid Transaction"); location.assign("'.$db->base_url().'users.php?user=seller")</script>';
				exit;
			}

			echo '<h4 class="text-center">You Have '.$durs.' Left.</h4>';
			echo '<div class="form-group">';
				echo '<label class="control-label" for="selfdurations">';
				echo '<i class="glyphicon glyphicon-time"></i> Self Durations:';
				echo '</label>';
				echo '<select id="selfdurations" name="selfdurations" class="form-control">';
					echo $duration;
				echo '</select>';
			echo '</div>';

		}else{
			echo '<script> alert("Invalid Transaction"); location.assign("'.$db->base_url().'users.php?user=seller")</script>';
			return false;
		}
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>
