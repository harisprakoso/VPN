<?php
header('Content-Type: application/json');
include_once("../../config/connection.php");
/*
if(isset($_SESSION['user'])){
	if($_SESSION['user']['rank']=="Sub Reseller" || $_SESSION['user']['rank']=="Reseller" || $_SESSION['user']['rank']=="Sub Administrator" || $_SESSION['user']['rank']=="Administrator" ){
		$query="SELECT `code_name`,IF(`is_used`=1,'Yes','No') as 'is_used',IF(`date_used`='','-',`date_used`) as 'date_used',`time_stamp`,`gen_date`,CONCAT(FLOOR(`duration`/86400),' day(s) ',sec_to_time(`duration`)) as 'duration', IF(`category`='premium','Premium','VIP') as 'voucher_type',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`reseller_id`) as 'reseller', IF(`user_id`=0,'-',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`user_id`)) as 'client' FROM `vouchers` as tb1 WHERE `user_id`=".$_SESSION['user']['id'] . " OR `reseller_id`=".$_SESSION['user']['id'] ;
	}else{
		$query="SELECT `code_name`,IF(`is_used`=1,'Yes','No') as 'is_used',IF(`date_used`='','-',`date_used`) as 'date_used',`time_stamp`,`gen_date`,CONCAT(FLOOR(`duration`/86400),' day(s) ',sec_to_time(`duration`)) as 'duration', IF(`category`='premium','Premium','VIP') as 'voucher_type',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`reseller_id`) as 'reseller', IF(`user_id`=0,'-',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`user_id`)) as 'client' FROM `vouchers` as tb1 WHERE `user_id`=".$_SESSION['user']['id'] ;
	}
}else{
	$return_arr["message"]=" Unauthorized Action.";
}
echo json_encode($db -> return_result($query));
*/
$data = array();
$values = array();
if(isset($_SESSION['user'])){
	if($_SESSION['user']['id']== 1
	|| $_SESSION['user']['rank']=="Administrator" 
	|| $_SESSION['user']['rank']=="Sub Administrator"
	|| $_SESSION['user']['rank']=="Reseller"
	|| $_SESSION['user']['rank']=="Sub Reseller")
	{
		$sql = "SELECT * FROM vouchers WHERE reseller_id='".$_SESSION['user']['id']."' OR user_id='".$_SESSION['user']['id']."'";
	}else{
		$sql = "SELECT * FROM vouchers WHERE user_id='".$_SESSION['user']['id']."'";
	}
	$query = $db->sql_query($sql);
	while($row = $db->sql_fetchassoc($query))
	{
		if($row['is_used'] == 1)
		{
			$is_used = 'Yes';
		}else{
			$is_used = 'No';
		}
		
		if($row['date_used'] == "")
		{
			$date_used = "--";
		}else{
			$date_used = date('F d, Y h:i:s', strtotime($row['date_used']));
		}
			
		$gen_date = date('F d, Y h:i:s', strtotime($row['gen_date']));
		
		if($row['category'] == 'premium'){
			$voucher_type = 'Premium';
		}else{
			$voucher_type = 'VIP';
		}

		$dur = $db->calc_time($row['duration']);
		$duration = $dur['days'] . " Day(s), " . $dur['hours'] . " Hour(s) " . $dur['minutes'] . " Minutes.";
		
		$values['code_name'] = $row['code_name'];
		$values['is_used'] = $is_used;
		$values['date_used'] = $date_used;
		$values['voucher_type'] = $voucher_type;
		$values['gen_date'] = $gen_date;
		$values['duration'] = $duration;
		
		$chk_client = $db->sql_query("SELECT user_name FROM users WHERE user_id='".$row['user_id']."'");
		$client_row = $db->sql_fetchassoc($chk_client);
		if($row['is_used'] == 1)
		{
			if($client_row['user_name'] == ''){
				$client = 'Deleted User';
			}else{
				$client = $client_row['user_name'];
			}
		}else{
			if($client_row['user_name'] == ''){
				$client = '';
			}else{
				$client = $client_row['user_name'];
			}
		}
		$values['client'] = $client;
		
		$chk_reseller = $db->sql_query("SELECT user_name FROM users WHERE user_id='".$row['reseller_id']."'");
		$reseller_row = $db->sql_fetchassoc($chk_reseller);
		$values['reseller'] = $reseller_row['user_name'];
		array_push($data, $values);
	}
	echo json_encode($data);
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>