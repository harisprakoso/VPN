<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator" )
{
	if(isset($_POST['submitted']))
	{
		$chk = $_POST['chk'];
		$chkcount = count($chk);
			
		if(!isset($chk))
		{
			echo "<script> alert('You need to check the checkbox! At least one checkbox Must be Selected !!!'); </script>";
			header("location: users.php?user=seller");
		}
		else
		{
			for($i=0; $i<$chkcount; $i++)
			{
				$chk_id = $chk[$i];
				$chk_id = $db->encryptor('decrypt',$chk_id);

				$query = $db->sql_query("SELECT * FROM users WHERE user_id!=1 AND user_id='".$chk_id."'");
				while($chk_rows = $db->sql_fetchassoc($query))
				{
					$user_id = $chk_rows['user_id'];
					
					$user_query = $db->sql_query("DELETE FROM users WHERE user_id!=1 AND user_id='".$user_id."'");
					if($user_query)
					{
						$db->HandleSuccess('Successfully! Deleted Account!...');
					}else{
						$db->HandleError('Sorry! Delete Account is Failed!');
					}
				}
			}
		}
	}
	echo $db->GetSuccessMessage();
	echo $db->GetErrorMessage();
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>