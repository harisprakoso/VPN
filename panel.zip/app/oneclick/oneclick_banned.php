<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator")
{
	if(isset($_POST['submitted']))
	{
		$chk = $_POST['chk'];
		$chkcount = count($chk);
		
		if(!isset($chk))
		{
			echo "<script> alert('You need to check the checkbox! At least one checkbox Must be Selected !!!'); </script>";
			header("location: users.php?user=seller");
		}
		else
		{
			for($i=0; $i<$chkcount; $i++)
			{
				$chk_id = $chk[$i];
				$chk_id = $db->encryptor('decrypt',$chk_id);

				$query = $db->sql_query("SELECT * FROM users WHERE user_id!=1 AND user_id='".$chk_id."'");

				while($row = $db->sql_fetchassoc($query))
				{
					$id_user = $row['user_id'];
					$query = $db->sql_query("UPDATE users SET is_ban=0, is_active=0, is_suspend=0, is_offense=is_offense+3 WHERE user_id='".$id_user."'");
					if($query){
						$db->HandleSuccess("Successfully! Banned Account!...");
					}else{
						$db->HandleError("Sorry! Failed to Banned Account");
					}
				}
			}
		}
	}
	echo $db->GetSuccessMessage();
	echo $db->GetErrorMessage();
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>