<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller")
{
	if(isset($_POST['submitted']))
	{
		$chk = $_POST['chk'];
		$chkcount = count($chk);
			
		if(!isset($chk))
		{
			echo "<script> alert('You need to check the checkbox! At least one checkbox Must be Selected !!!'); </script>";
			header("location: users.php?user=seller");
		}
		else
		{
			for($i=0; $i<$chkcount; $i++)
			{
				$chk_id = $chk[$i];
				$chk_id = $db->encryptor('decrypt',$chk_id);

				$chk_qry = $db->sql_query("SELECT * FROM users WHERE user_id!=1 AND user_id='".$chk_id."'");
				
				while($chk_rows = $db->sql_fetchassoc($chk_qry))
				{
					$id_user = $chk_rows['user_id'];
					
					if($chk_rows['duration']>0 || $chk_rows['vip_duration']>0 || $chk_rows['is_credits']>0)
					{
						$db->HandleError('Sorry! You cannot Delete this Account...');
					}else{
						if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator" )
						{
							$user_query = $db->sql_query("DELETE FROM users WHERE user_id!=1 AND user_id='".$id_user."'");						
						}else{
							$user_query = $db->sql_query("DELETE FROM users WHERE user_id!=1 AND is_reseller!=4 AND user_id='".$id_user."' AND upline='".$_SESSION['user']['id']."'");
						}
					}
				}
			}
		}
	}
	
	if($user_query)
	{
		$db->HandleSuccess('Successfully! Deleted Account!...');
	}else{
		$db->HandleError('Sorry! Delete Account is Failed!');
	}
	echo $db->GetSuccessMessage();
	echo $db->GetErrorMessage();
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>