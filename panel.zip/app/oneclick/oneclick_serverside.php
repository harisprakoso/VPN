<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';
//include_once("../../config/connection.php");

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller")
{
	$requestData= $_REQUEST;
	$columns = array( 
		0	=> 'user_id',
		1	=> 'user_name', 
		2	=> 'duration',
		3	=> 'vip_duration',
		4	=> 'credits',
		5	=> 'is_reseller',
		6	=> 'upline',
		7	=> null
	);
	
	if($_SESSION['user']['id']== 1){
		$chk = 'user_id!=1 AND user_id!="'.$_SESSION['user']['id'].'"';
	}elseif($_SESSION['user']['id']>1 && $_SESSION['user']['rank']=="Administrator"){
		$chk = 'user_id!=1 AND user_id!="'.$_SESSION['user']['id'].' AND is_reseller!=4"';
	}else{
		$chk = 'user_id!=1 AND user_id!="'.$_SESSION['user']['id'].'" AND upline="'.$_SESSION['user']['id'].'"';
	}
	$qry = "SELECT * FROM users";

	$sql = $qry ." WHERE ".$chk." ORDER BY user_name ASC";
	$query = $db->sql_query($sql) or die();
	$totalData = $db->sql_numrows($query);
	$totalFiltered = $totalData;

	$sql = $qry ." WHERE 1=1 AND ".$chk." ";
	if( !empty($requestData['search']['value']) ) { 
		$sql.=" AND ( user_id LIKE '%".$requestData['search']['value']."%' "; 
		$sql.=" OR user_name LIKE '%".$requestData['search']['value']."%' ";
		$sql.=" OR duration LIKE '%".$requestData['search']['value']."%' ";
		$sql.=" OR vip_duration LIKE '%".$requestData['search']['value']."%' ";
		$sql.=" OR credits LIKE '%".$requestData['search']['value']."%' ";
		$sql.=" OR is_reseller LIKE '%".$requestData['search']['value']."%' ";
		$sql.=" OR upline LIKE '%".$requestData['search']['value']."%' ) ";
	}

	$query = $db->sql_query($sql) or die();
	$totalFiltered = $db->sql_numrows($query);
	$sql.="ORDER BY ". $columns[$requestData['order'][0]['column']]."  ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";

	$query = $db->sql_query($sql) or die();
	$data = array();
	while( $row = $db->sql_fetchassoc($query) )
	{
		$nestedData=array(); 
		$id = $row['user_id'];
		$code = $row['code'];
		
		if($row['duration'] <= 0 && $row['vip_duration'] <= 0 && $row['credits'] <= 0){
			$user = '<font color="red">'.$row['user_name'].'</font>';
		}else{
			$user = '<font color="green">'.$row['user_name'].'</font>';
		}
		
		if($row['user_id'] == 1 || $row['is_reseller'] == 4){
			$username = $user;
		}else{
			$username = $user;
		}

		if($row['user_id'] == 1 || $row['is_reseller'] == 4){
			$role = 'Administrator';
		}else
		if($row['is_reseller'] == 3){
			$role = 'Sub Administrator';
		}else
		if($row['is_reseller'] == 2){
			$role = 'Reseller';
		}else
		if($row['is_reseller'] == 1){
			$role = 'Sub Reseller';
		}else{
			$role = 'Member';
		}

		$dur = $db->calc_time($row['duration']);
		$dur2 = $db->calc_time($row['vip_duration']);
			
		if($row['duration'] <= 0){
			$premuim_duration = "<font color='red'>Not Active</font>";
		}elseif($row['duration'] < 3600){
			$premuim_duration = "<font color='red'>". $dur['days'] . "</font> Day(s), <font color='red'>" . $dur['hours'] . "</font> Hour(s) and <font color='orange'>" . $dur['minutes'] . "</font> Minutes Left.";	
		}else{
			$premuim_duration = "<font color='green'>". $dur['days'] . "</font> Day(s), <font color='green'>" . $dur['hours'] . "</font> Hour(s) and <font color='green'>" . $dur['minutes'] . "</font> Minutes Left.";
		}

		if($row['vip_duration'] <= 0){
			$vip_duration = "<font color='red'>Not Active</font>";
		}elseif($row['vip_duration'] < 3600){
			$vip_duration = "<font color='red'>". $dur2['days'] . "</font> Day(s), <font color='red'>" . $dur2['hours'] . "</font> Hour(s) and <font color='orange'>" . $dur2['minutes'] . "</font> Minutes Left.";	
		}else{
			$vip_duration = "<font color='green'>". $dur2['days'] . "</font> Day(s), <font color='green'>" . $dur2['hours'] . "</font> Hour(s) and <font color='green'>" . $dur2['minutes'] . "</font> Minutes Left.";
		}
			
		if($row['credits'] <= 0)
		{
			$credits = '<font color="red">'.$row['credits'].'</font>';
		}else{
			$credits = '<font color="green">'.$row['credits'].'</font>';
		}

		$select_qry = $db->sql_query("SELECT user_name FROM users WHERE user_id='".$row['upline']."'");
		$select_row = $db->sql_fetchassoc($select_qry);
		if($select_row['user_name']){
			$upline = $select_row['user_name'];
		}else{
			$upline = 'webmaster';
		}
		
		if($row['is_active'] == 0 && $row['is_freeze'] == 0 && $row['is_suspend'] == 1 && $row['is_ban'] == 1){
			$status = '<label class="label label-info">Freezed</label>';
		}else
		if($row['is_active'] == 0 && $row['is_freeze'] == 1 && $row['is_suspend'] == 0 && $row['is_ban'] == 1){
			$status = '<label class="label label-warning">Suspended</label>';
		}else
		if($row['is_active'] == 0 && $row['is_freeze'] == 1 && $row['is_suspend'] == 0 && $row['is_ban'] == 0){
			$status = '<label class="label label-danger">Banned</label>';
		}else
		if($row['is_active'] == 0){
			$status = '<label class="label label-primary">Deactivated</label>';
		}else{
			$status = '<label class="label label-success">Live</label>';
		}
		
		$nestedData[] = '<input type="checkbox" name="chk[]" class="chk-box" value="'.$db->encryptor('encrypt',$id).'">';
		$nestedData[] = $username;
		$nestedData[] = $premuim_duration;
		$nestedData[] = $vip_duration;
		$nestedData[] = $credits;
		$nestedData[] = $role;
		$nestedData[] = $upline;
		if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator" || $_SESSION['user']['rank']=="Sub Administrator" || $_SESSION['user']['rank']=="Reseller"){
		$nestedData[] = $status . '<hr /> <button type="button" class="btn btn-sm btn-primary" onClick="view_info('.$id.','.$code.')">Details</button>
						 <button type="button" class="btn btn-sm btn-warning" onClick="view_profile('.$id.')">Profile</button>
						 <button type="button" class="btn btn-sm btn-success" onClick="edit_user('.$id.')">Edit</button>
						 <button type="button" class="btn btn-sm btn-info" onClick="credit_user('.$id.')">Credits</button>';
		}else{
		$nestedData[] = $status . ' <button type="button" class="btn btn-sm btn-primary" onClick="view_info('.$id.','.$code.')">Details</button>
						 <button type="button" class="btn btn-sm btn-warning" onClick="view_profile('.$id.')">Profile</button>
						 <button type="button" class="btn btn-sm btn-success" onClick="edit_user('.$id.')">Edit</button>';	
		}
		$data[] = $nestedData;
	}

	$json_data = array(
		"draw"            => intval( $requestData['draw'] )? intval( $_REQUEST['draw'] ) : 0,
		"recordsTotal"    => intval( $totalData ),
		"recordsFiltered" => intval( $totalFiltered ),
		"data"            => ( $data )
		);

	echo json_encode($json_data);
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>	