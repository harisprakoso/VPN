<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller"){

$premium_encrypts = $db->encryptor('encrypt', 'premium');
$vip_encrypts = $db->encryptor('encrypt', 'vip');
$add_encrypts = $db->encryptor('encrypt', 'add');
$substract_encrypts = $db->encryptor('encrypt', 'substract');

for($i=0; $i<366; $i++)
{
	$encrypt_days .= '<option value="'.base64_encode($db->encrypt_key($db->encrypt_key($i))).'">'.$i.'</option>';
}

for($i=0; $i<25; $i++)
{
	$encrypt_hours .= '<option value="'.urlencode($db->encrypt_key($db->encrypt_key($i))).'">'.$i.'</option>';
}

	if(!empty($_POST['category_selected']))
	{
		$info = '';
		$category_selected = $_POST['category_selected'];
		if($category_selected == 'credits_selected')
		{
			$info .= '
			<div class="form-group input-group">
				<label class="input-group-addon control-label" for="add_credits"><i class="glyphicon glyphicon-barcode"></i></label>
				<input class="form-control" type="text" id="add_credits" name="add_credits" min="1" >
			</div>
			<div class="form-group input-group">
				<label class="input-group-addon control-label" for="category"><i class="glyphicon glyphicon-list"></i>: </label>
				<select class="form-control credits" id="category" name="category">
					<option value="'.$add_encrypts.'">Add Credits</option>
					<option value="'.$substract_encrypts.'">Substract Credits</option>
				</select>
			</div>
			
			<button type="button" class="btn btn-success btn-block" onclick="oneclickCredits()">
				One Click Credits
			</button>
			';
		}
		
		if($category_selected == 'duration_selected')
		{
			$info .='
			<div class="form-group form-material floating">
				<select class="form-control" id="dayss" name="dayss">
					'.$encrypt_days.'
				</select>
				<label class="floating-label control-label" for="dayss">
					<i class="glyphicon glyphicon-time"></i> Day(s):
				</label>
			</div>
			
			<div class="form-group form-material floating">
				<select class="form-control" id="hourss" name="hourss">
					'.$encrypt_hours.'
				</select>
				<label class="floating-label control-label" for="hourss">
					<i class="glyphicon glyphicon-time"></i> Hour(s):
				</label>
			</div>
			
			<div class="form-group input-group">
				<label class="input-group-addon control-label" for="category"><i class="glyphicon glyphicon-list"></i>: </label>
				<select class="form-control" id="category" name="category">
					<option value="'.$premium_encrypts.'">Premium</option>
					<option value="'.$vip_encrypts.'">VIP</option>
				</select>
			</div>
			
			<div class="form-group input-group">
				<label class="input-group-addon control-label" for="category_ext"><i class="glyphicon glyphicon-list"></i>: </label>
				<select class="form-control" id="category_ext" name="category_ext">
					<option value="'.$add_encrypts.'">Add Duration</option>
					<option value="'.$substract_encrypts.'">Substract Duration</option>
				</select>
			</div>
			
			<button type="button" class="btn btn-success btn-block" onclick="oneclickDuration()">
				One Click Duration
			</button>
			';
		}
		
		if($category_selected == 'delete_selected')
		{
			$info .= '
			<p>
			Note: This Function is Account Deletion for <br />
			<font color="red">0</font> Duration / Credits....
			</p>
			<button type="button" class="btn btn-success btn-block" onclick="oneclickDelete()">
				One Click Delete
			</button>';
		}

		if($category_selected == 'suspend_selected')
		{
			$info .= '
			<p>
			Note: This Function is Forcing to suspend the users!...
			</p>
			<button type="button" class="btn btn-success btn-block" onclick="oneclickSuspend()">
				One Click Suspension
			</button>';
		}
		
		if($category_selected == 'freeze_selected')
		{
			$info .= '
			<p>
			Note: This Function is Forcing to Freezing the account!...
			</p>
			<button type="button" class="btn btn-success btn-block" onclick="oneclickFreeze()">
				One Click Freeze
			</button>';
		}		
		
		if($category_selected == 'forcedelete_selected')
		{
			$info .= '
			<p>
			Note: This Function is Forcing to Deleted The Users...
			Active Premium, VIP, and even seller account....
			</p>
			<button type="button" class="btn btn-success btn-block" onclick="oneclickForcedelete()">
				One Click Force Delete
			</button>';
		}
		
		if($category_selected == 'banned_selected')
		{
			$info .= '
			<p>
			Note: This Function is Banning Account....
			</p>
			<button type="button" class="btn btn-success btn-block" onclick="oneclickBanned()">
				One Click Banned Account
			</button>';
		}
		echo $info;
	}else{
		header("location: users.php?user=seller");
		exit;
	}
}else{
	header("location: users.php?user=seller");
	exit;
}
?>
