<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if(empty($_POST['signin_username']) || empty($_POST['signin_password'])){
	header("location: ".$db->base_url()."users.php?user=seller");
}

if(!isset($_SESSION['user'])){
	
if(isset($_POST['submitted']))
{
	$chk_attempts = $db->sql_query("SELECT * FROM login_attempts WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
	$datas = $db->sql_fetchassoc($chk_attempts);
	$attempts = $datas["attempts"]+1;
	$timestamp = $datas['timestamp'];
	$time = time();
	$onehour = $time + 300;
	$time_check = $timestamp - $time;
	$timedelete = $time - 100;
	$dur = $db->calc_time($time_check);
	$onehour_temp = $dur['minutes'] . " minutes " . $dur['seconds'] . " seconds";
	$deletetime = $db->sql_query("DELETE FROM login_attempts WHERE timestamp < $time");	
	$CSRFtoken = $db->Sanitize($_POST['CSRFtoken']);
	
	if($datas["attempts"] >= 3){
			$db->HandleError("Sorry! You cannot login your at this time 
			". $onehour_temp);
	}else{
		$chkUsername = trim($_POST['signin_username']);
		$chkUsername = $db->encryptor('decrypt',$chkUsername);
		$username = $db->decrypt_key($chkUsername);
		$username = $db->SanitizeForSQL($username);
		$password = trim($_POST['signin_password']);
		$pwdmd5 = $db->encrypt_key($db->encryptor('encrypt', $password));
		$qry = "SELECT * FROM users WHERE user_name='".$username."' and user_pass='".$pwdmd5."'";
		$result = $db->sql_query($qry);
		$row = $db->sql_fetchassoc($result);
		if($result || $row == 1)
		{
			if($row['user_pass'] != $pwdmd5 || $row['user_name'] != $username){
				$db ->HandleError("Error logging in. The username or password does not match
				Loggin Attempt: " . $attempts);
				
				if($datas)
				{
					if($datas["attempts"]>=3)
					{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour' 
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
							
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}else{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour'
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
								
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}
				}else{
					$db->sql_query("INSERT INTO login_attempts 
					(attempts, ip, lastlogin, timestamp) 
					values
					(1, '".$_SERVER['REMOTE_ADDR']."', NOW(), $onehour)");
						
					$db->sql_query("INSERT INTO login_attempts_logs 
					(ip, user_name, logs_date) 
					values
					('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
				}
			}
			
			if($row['user_pass'] == $pwdmd5 
			&& $row['user_name'] == $username 
			&& $row['is_validated'] == 1
			&& $row['is_freeze'] ==1 
			&& $row['is_ban'] ==1
			&& $row['is_suspend'] ==1
			&& $row['is_active'] != 1)
			{
				$db ->HandleError("Your Account is deactivated, Please! contact your system administrator.");
				
				if($datas)
				{
					if($datas["attempts"]>=3)
					{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour' 
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
							
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}else{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour'
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
								
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}
				}else{
					$db->sql_query("INSERT INTO login_attempts 
					(attempts, ip, lastlogin, timestamp) 
					values
					(1, '".$_SERVER['REMOTE_ADDR']."', NOW(), $onehour)");
						
					$db->sql_query("INSERT INTO login_attempts_logs 
					(ip, user_name, logs_date) 
					values
					('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
				}
			}
			
			if($row['user_pass'] == $pwdmd5 
			&& $row['user_name'] == $username 
			&& $row['is_validated'] != 1
			&& $row['is_freeze'] ==1 
			&& $row['is_ban'] ==1
			&& $row['is_suspend'] ==1
			&& $row['is_active'] != 1)
			{
				$db ->HandleError("Your Account is not activated, Please! Confirm your account at your email address.");
			
				if($datas)
				{
					if($datas["attempts"]>=3)
					{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour' 
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
							
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}else{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour'
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
								
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}
				}else{
					$db->sql_query("INSERT INTO login_attempts 
					(attempts, ip, lastlogin, timestamp) 
					values
					(1, '".$_SERVER['REMOTE_ADDR']."', NOW(), $onehour)");
						
					$db->sql_query("INSERT INTO login_attempts_logs 
					(ip, user_name, logs_date) 
					values
					('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
				}
			}
			
			if($row['user_pass'] == $pwdmd5 
			&& $row['user_name'] == $username 
			&& $row['is_validated'] == 1
			&& $row['is_freeze'] ==1 
			&& $row['is_ban'] ==1
			&& $row['is_suspend'] !=1
			&& $row['is_active'] != 1)
			{
				if($row['is_offense'] == 1)
				{
					$days = 86400 * 3;
					$suspend_date = "until ". date('F d, Y h:i:s', strtotime($row['suspend_date']) + $days);
					$db ->HandleError("Your Account is Suspended ".$suspend_date.", Please! Contact The System Administrator.");
				}elseif($row['is_offense'] == 2){
					$days = 86400 * 7;
					$suspend_date = "until ". date('F d, Y h:i:s', strtotime($row['suspend_date']) + $days);
					$db ->HandleError("Your Account is Suspended ".$suspend_date.", Please! Contact The System Administrator.");	
				}
			
				if($datas)
				{
					if($datas["attempts"]>=3)
					{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour' 
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
							
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}else{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour'
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
								
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}
				}else{
					$db->sql_query("INSERT INTO login_attempts 
					(attempts, ip, lastlogin, timestamp) 
					values
					(1, '".$_SERVER['REMOTE_ADDR']."', NOW(), $onehour)");
						
					$db->sql_query("INSERT INTO login_attempts_logs 
					(ip, user_name, logs_date) 
					values
					('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
				}
			}
			
			if($row['user_pass'] == $pwdmd5 
			&& $row['user_name'] == $username 
			&& $row['is_validated'] == 1
			&& $row['is_freeze'] ==1 
			&& $row['is_ban'] !=1
			&& $row['is_suspend'] !=1
			&& $row['is_active'] != 1)
			{
				$db ->HandleError("Your Account is Banned, Please! Contact The System Administrator.");
			
				if($datas)
				{
					if($datas["attempts"]>=3)
					{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour' 
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
							
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}else{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour'
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
								
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}
				}else{
					$db->sql_query("INSERT INTO login_attempts 
					(attempts, ip, lastlogin, timestamp) 
					values
					(1, '".$_SERVER['REMOTE_ADDR']."', NOW(), $onehour)");
						
					$db->sql_query("INSERT INTO login_attempts_logs 
					(ip, user_name, logs_date) 
					values
					('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
				}
			}
			
			if($row['user_pass'] == $pwdmd5 
			&& $row['user_name'] == $username 
			&& $row['is_validated'] == 1
			&& $row['is_freeze'] !=1 
			&& $row['is_ban'] ==1
			&& $row['is_suspend'] ==1
			&& $row['is_active'] != 1)
			{
				$db ->HandleError("Your Account is Freeze, Please! Contact The Person who handle your account.");
			
				if($datas)
				{
					if($datas["attempts"]>=3)
					{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour' 
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
							
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}else{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour'
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
								
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
					}
				}else{
					$db->sql_query("INSERT INTO login_attempts 
					(attempts, ip, lastlogin, timestamp) 
					values
					(1, '".$_SERVER['REMOTE_ADDR']."', NOW(), $onehour)");
						
					$db->sql_query("INSERT INTO login_attempts_logs 
					(ip, user_name, logs_date) 
					values
					('".$_SERVER['REMOTE_ADDR']."', '".$username."', NOW())");
				}
			}
			
			if($row['user_pass'] == $pwdmd5 
			&& $row['user_name'] == $username 
			&& $row['is_validated'] == 1
			&& $row['is_freeze'] ==1 
			&& $row['is_ban'] ==1
			&& $row['is_suspend'] ==1
			&& $row['is_active'] == 1)
			{
				$db->sql_query("UPDATE users SET token='".$CSRFtoken."' WHERE user_name='".$row['user_name']."'");
				$db->setLogin($row['user_id']);
				$db->sql_query("DELETE FROM login_attempts WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
				$db->sql_query("DELETE FROM login_attempts_logs WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
				echo "<script> alert('Successfully logged-in!!!'); location.assign('".$db->base_url()."'); </script>";
			}
		}
	}
}

}else{
	$db ->HandleError("Already Authenticated.");
}

echo $db->GetErrorMessage();
?>