<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if(empty($_POST['username'])){
    header("location: ".$db->base_url()."users.php?user=seller");
}else{
	if(isset($_POST['submitted']))
	{
		$values = array();
		$CSRFtoken = $db->Sanitize($_POST['CSRFtoken']);
		$chkUsername = $db->Sanitize($_POST['username']);
		$chk_attempts = $db->sql_query("SELECT * FROM login_attempts WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
		$datas = $db->sql_fetchassoc($chk_attempts);
		$attempts = $datas["attempts"]+1;
		$timestamp = $datas['timestamp'];
		$time = time();
		$onehour = $time + 300;
		$time_check = $timestamp - $time;
		$timedelete = $time - 100;
		$dur = $db->calc_time($time_check);
		$onehour_temp = $dur['minutes'] . " minutes " . $dur['seconds'] . " seconds";
		$deletetime = $db->sql_query("DELETE FROM login_attempts WHERE timestamp < $time");	
		
		if($datas["attempts"] >= 3){
			$db->HandleError("Sorry! You cannot login your at this time 
			". $onehour_temp);
			$values['status'] = 0;
			$values['message'] = $db->GetErrorMessage();
		}else{
			if(empty($CSRFtoken)){
				$db->HandleError("Sorry! invalid token!
				Loggin Attempt: " . $attempts);
				$values['status'] = 0;
				$values['message'] = $db->GetErrorMessage();
			}
			if(empty($chkUsername))
			{
				$db->HandleError("Username is empty!
				Loggin Attempt: " . $attempts);
				$values['status'] = 0;
				$values['message'] = $db->GetErrorMessage();

				if($datas)
				{
					$values['status'] = 0;
					if($datas["attempts"]>=3)
					{
						$db->HandleError("Sorry! You cannot login your at this time 
						". $onehour_temp);
				
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour' 
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
								
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$chkUsername."', NOW())");
					}else{
						$db->sql_query("UPDATE login_attempts 
						SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour'
						WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
								
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$chkUsername."', NOW())");
					}
				}else{
					$values['status'] = 0;
					$db->sql_query("INSERT INTO login_attempts 
					(attempts, ip, lastlogin, timestamp) 
					values
					(1, '".$_SERVER['REMOTE_ADDR']."', NOW(), $onehour)");
						
					$db->sql_query("INSERT INTO login_attempts_logs 
					(ip, user_name, logs_date) 
					values
					('".$_SERVER['REMOTE_ADDR']."', '".$chkUsername."', NOW())");
				}
			}else{
				$query = $db->sql_query("SELECT user_name FROM users WHERE user_name='".$db->SanitizeForSQL($chkUsername)."'");
				$num = $db->sql_numrows($query);
				if($num > 0)
				{
					$row = $db->sql_fetchassoc($query);
					$username = $db->encryptor('encrypt', $db->encrypt_key($row['user_name']));
					
					/* Token Security */
					$db->sql_query("UPDATE users SET token='".$CSRFtoken."' WHERE user_name='".$row['user_name']."'");
					
					$values['username'] = '<h3 class="text-center">Hello! '.$row['user_name'].'</h3>';
					$values['message'] = $username;
					$values['status'] = 1;
					
					$db->sql_query("DELETE FROM login_attempts WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
					$db->sql_query("DELETE FROM login_attempts_logs WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
				}else{
					$db->HandleError("The ".$chkUsername." is not Registered!
					Loggin Attempt: " . $attempts);
					$values['status'] = 0;
					$values['message'] = $db->GetErrorMessage();
					
					if($datas)
					{
						if($datas["attempts"]>=3)
						{
							$db->sql_query("UPDATE login_attempts 
							SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour' 
							WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
								
							$db->sql_query("INSERT INTO login_attempts_logs 
							(ip, user_name, logs_date) 
							values
							('".$_SERVER['REMOTE_ADDR']."', '".$chkUsername."', NOW())");
						}else{
							$db->sql_query("UPDATE login_attempts 
							SET attempts=".$attempts.", lastlogin=NOW(), timestamp='$onehour'
							WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
									
							$db->sql_query("INSERT INTO login_attempts_logs 
							(ip, user_name, logs_date) 
							values
							('".$_SERVER['REMOTE_ADDR']."', '".$chkUsername."', NOW())");
						}
					}else{
						$db->sql_query("INSERT INTO login_attempts 
						(attempts, ip, lastlogin, timestamp) 
						values
						(1, '".$_SERVER['REMOTE_ADDR']."', NOW(), $onehour)");
						
						$db->sql_query("INSERT INTO login_attempts_logs 
						(ip, user_name, logs_date) 
						values
						('".$_SERVER['REMOTE_ADDR']."', '".$chkUsername."', NOW())");
					}
				}
			}
		
		}
		echo json_encode($values);
	}
}
?>