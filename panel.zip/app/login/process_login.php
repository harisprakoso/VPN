<?php
include_once("../../config/connection.php");
$return_arr["status"]=0;
$return_arr["message"]=" No Action.";//.$_POST['username'].$_POST['password'];
$get_uid="";
if(!isset($_SESSION['user'])){
	if(isset($_POST['username'],$_POST['password'])){
		$post_username = $db -> Sanitize($_POST['username']);
		$post_password = $db -> Sanitize($_POST['password']);
		$user_pass = $db->encrypt_key($db->encryptor('encrypt',$post_password));
		$get_result = $db -> select("SELECT COUNT(*) FROM `users` WHERE `user_name`='".$db->SanitizeForSQL($post_username)."' AND `user_pass`='".$db->SanitizeForSQL($user_pass)."'");
		if($get_result != 0){
			$uid = $db -> select("SELECT `user_id` FROM `users` WHERE `user_name`='".$db->SanitizeForSQL($post_username)."' AND `user_pass`='".$db->SanitizeForSQL($user_pass)."'");
			$db ->  setLogin($uid);
			$return_arr["status"]=1;
			$return_arr["message"]=" Login Successful. Please wait...";
		}else{
			$return_arr["status"]=0;
			$return_arr["message"]=" Invalid Login. Please try again.";
		}
	}
}else{
	$return_arr["message"]=" Already Authenticated.";
}
//$return_arr["message"] = $get_uid;
echo json_encode($return_arr);
?>