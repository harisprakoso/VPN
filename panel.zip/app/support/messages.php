<?php
header('Content-Type: application/json');
include_once("../../config/connection.php");

if(isset($_SESSION['user']['rank'])){
	if($_SESSION['user']['rank']=="Admin"){
		$query="SELECT 
		(SELECT B.`user_name` FROM `users` AS B WHERE A.`user_id_from`=B.`user_id`) AS 'user_name',
		(SELECT B.`full_name` FROM `users` AS B WHERE A.`user_id_from`=B.`user_id`) AS 'full_name',
		A.`timestamp`,
		IF(A.`is_unread`=1,'Yes','No') AS 'is_unread',
		CONCAT('<button class=\'btn btn-info\' onclick=\"view_message(\'',A.`user_id_from`,'\')\">View</button> ',
		'<button class=\'btn btn-danger\' onclick=\"delete_message(\'',A.`user_id_from`,'\')\">Delete</button>'
		) AS 'action'
		FROM `messages` AS A WHERE A.`user_id_to`=1 GROUP BY A.`user_id_from`";
	}
}
echo json_encode($db -> return_result($query));
?>