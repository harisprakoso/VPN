<?php
header('Content-Type: application/json');
include_once("../../config/connection.php");

$return_arr["status"]=0;
$return_arr["message"]=" No Action.";

if(isset($_SESSION['user']['id'])){
	if(isset($_POST['message'])){
		$message = $db -> escape(htmlspecialchars($_POST['message']));
		$id = $db -> escape(htmlspecialchars($_POST['id']));
		if($_SESSION['user']['id']=="1"){
			$db -> sql_query("INSERT INTO `messages`(`user_id_from`,`user_id_to`,`content`,`is_unread`) VALUES (1,$id,'$message',1)");
		}else{
			$db -> sql_query("INSERT INTO `messages`(`user_id_from`,`user_id_to`,`content`,`is_unread`) VALUES (".$_SESSION['user']['id'].",1,'$message',1)");
		}
		$return_arr["status"]=1;
		$return_arr["message"]=" Sent.";
	}
}
echo json_encode($return_arr);
?>