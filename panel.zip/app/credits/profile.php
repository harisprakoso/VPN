<!DOCTYPE html>
<html>

<?php
include('components/header.php');
?>
<body>
<?php
include('components/nav.php');
include("components/sidebar.php");
//$current_uid= $_SESSION['user']['id'];
if(!isset($_SESSION['user'])){
	header("location: login.php");
}
$get_id=0;
if(isset($_GET['user'])){
	$get_id = $db -> escape($_GET['user']);
	if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){
		header("location: profile.php");
	}
}else{
	$get_id = $current_uid;
}

	$profile_query = $db->sql_query("SELECT * FROM `users` WHERE `user_id`=$get_id");
	$profile_info = $db->sql_fetchassoc($profile_query);

	$dur = $db->calc_time($profile_info['duration']);

	$duration = $dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minute(s)";

	$dur2 = $db->calc_time($profile_info['vip_duration']);

	$vip_duration = $dur2['days'] . " day(s), " . $dur2['hours'] . " hour(s) and " . $dur2['minutes'] . " minute(s)";
	
	$date = date_create(date('Y-m-d H:i:s'));
	
	date_add($date, date_interval_create_from_date_string($profile_info['duration'].' seconds'));
	$premium_expiration = date_format($date, 'm/d')."/".substr(date_format($date, 'Y'),2,2);

	date_add($date, date_interval_create_from_date_string($profile_info['vip_duration'].' seconds'));
	$vip_expiration = date_format($date, 'm/d')."/".substr(date_format($date, 'Y'),2,2);
	
	$premium_status="Active";
	if($profile_info['duration']==0){
		$premium_status="Inactive";
		$premium_expiration="--";
	}
	
	$vip_status="Active";
	if($profile_info['duration']==0){
		$vip_status="Inactive";
		$vip_expiration="--";
	}
	
	$user_rank="";
	if($profile_info['is_reseller']==4){
		$user_rank="Administrator";
	}elseif($profile_info['is_reseller']==3){
		$user_rank="Sub Administrator";
	}elseif($profile_info['is_reseller']==2){
		$user_rank="Reseller";
	}elseif($profile_info['is_reseller']==1){
		$user_rank="Sub Reseller";
	}else{
		$user_rank="Client";
	}
	if($get_id==1){
		$user_rank="Administrator";
	}

	if($profile_info['is_suspend']==1)
	{
		$is_suspend = 'Live';
	}else{
		$is_suspend = 'Suspended';
	}
	
	if($profile_info['is_freeze']==1)
	{
		$is_freeze = 'Live';
	}else{
		$is_freeze = 'Freezed';
	}
?>	
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-user"></span></a></li>
				<li class="active">View Account Page</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-blue panel-widget ">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-shopping-cart glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo $profile_info['credits'];?></div>
							<div class="text-muted">Credits</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-star glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo $premium_status;?></div>
							<div class="text-muted">Premium</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-red panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-time glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo $premium_expiration;?> </div>
							<div class="text-muted">Expiration</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-star glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo $vip_status;?></div>
							<div class="text-muted">VIP</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-red panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-time glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo $vip_expiration;?> </div>
							<div class="text-muted">Expiration</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-user glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="medium"><strong><?php echo $user_rank;?></strong></div>
							<div class="text-muted">User Type</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-user glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo $is_suspend;?></div>
							<div class="text-muted">Suspend Status</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-user glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php echo $is_freeze;?></div>
							<div class="text-muted">Freeze Status</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Account Info</div>
					<div class="panel-body">
						<div class="col-md-6">
							<div class="form-group">
								<label>Full Name</label>
								<input class="form-control" readonly value="<?php echo htmlspecialchars($profile_info['full_name']);?>">
							</div>

							<div class="form-group">
								<label>Email</label>
								<input class="form-control" type="email" readonly value="<?php echo htmlspecialchars($profile_info['user_email']);?>">
							</div>

							<div class="form-group">
								<label>Address</label>
								<input class="form-control" type="text" readonly value="<?php echo htmlspecialchars($profile_info['location']);?>">
							</div>

							<div class="form-group">
								<label>Mode of Payment (Reseller)</label>
								<input class="form-control" type="text" readonly value="<?php echo htmlspecialchars($profile_info['payment']);?>">
							</div>

							<div class="form-group">
								<label>Contact Info</label>
								<input class="form-control" type="text" readonly value="<?php echo htmlspecialchars($profile_info['contact']);?>">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Reseller</label>
								<input type="text" class="form-control" readonly value="<?php echo htmlspecialchars($db -> select("SELECT `full_name` FROM `users` WHERE `user_id`=".$profile_info['upline']));?>">
							</div>
							<div class="form-group">
								<label>Premium Duration</label>
								<input type="text" class="form-control" readonly value="<?php echo $duration; ?>">
							</div>
							<div class="form-group">
								<label>VIP Duration</label>
								<input type="text" class="form-control" readonly value="<?php echo $vip_duration; ?>">
							</div>
						</div>
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
	</div>	<!--/.main-->

<?php 
include("components/js.php");
?>
	
</body>

</html>
