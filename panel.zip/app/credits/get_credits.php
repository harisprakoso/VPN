<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"
|| $_SESSION['user']['rank']=="Sub Reseller")
{
	if(isset($_GET['uid']) == 0 || empty($_GET['uid']))
	{
		header("location: users.php?user=seller");
	}else{
		if(!isset($_GET['uid']) && empty($_GET['uid'])){
			echo '<script> alert("Invalid Transaction"); location.assign("users.php?user=seller")</script>';
			exit;	
		}else{
			$uid = $this->Sanitize($_GET['uid']);
			if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank'] == 'Administrator'){
				$qry = $this->sql_query("SELECT user_id, user_name, credits FROM users 
				WHERE user_id!=1 AND user_id='".$this->SanitizeForSQL($uid)."' LIMIT 1");
			}else{
				$qry = $this->sql_query("SELECT user_id, user_name, credits FROM users 
				WHERE user_id!=1 AND is_reseller!=4 AND upline='".$_SESSION['user']['id']."' AND user_id='".$this->SanitizeForSQL($uid)."' LIMIT 1");
			}

			$row = $this->sql_fetchassoc($qry);
			$values = array();	
			if($row){	
				$secret = $this->encryptor('encrypt',$row['user_name']);
				$secret = $this->encryptor('encrypt',$secret);
				$code = $this->encryptor('encrypt',$row['user_id']);
				$code = $this->encryptor('encrypt',$code);
				$values['secret'] = $secret;
				$values['code'] = $code;
				$values['username'] = $row['user_name'];
				$values['credits'] = $row['credits'];	
			}
			echo json_encode($values);
		}
	}
}else{
	header("location: users.php?user=seller");
}
?>