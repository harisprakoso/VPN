<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

$values = array();
if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller")
{
	if(isset($_POST['submitted']))
	{
		if(!isset($_POST['add_credits']) && !isset($_POST['secret']) && !isset($_POST['code']) 
			|| empty($_POST['add_credits']) || empty($_POST['secret']) || empty($_POST['code']))
		{				
			$db->HandleError('Sorry! the transaction is inavalid!..');
			$values['response'] = 0;
		}
		else
		{
			$get_secret = $db->encryptor('decrypt',$_POST['secret']);
			$get_secret = $db->encryptor('decrypt',$get_secret);
			$get_secret = $db->Sanitize($get_secret);
					
			$get_code = $db->encryptor('decrypt',$_POST['code']);
			$get_code = $db->encryptor('decrypt',$get_code);
			$get_code = $db->Sanitize($get_code);
					
			$add_credits = trim($_POST['add_credits']);
			$add_credits = $db->Sanitize($add_credits);
			if(preg_match('/[^0-9]/', $add_credits)) {
				$db->HandleError('Invalid input!');
				$values['response'] = 0;
			}
				
			$result_add = $db->sql_query("SELECT user_id, user_name, credits FROM users 
			WHERE user_id='".$db->SanitizeForSQL($get_code)."' AND user_name='".$db->SanitizeForSQL($get_secret)."'");
			$row_add = $db->sql_fetchassoc($result_add);
			$client_credits = $row_add['credits'];
				
			if($_SESSION['user']['rank']=="Sub Administrator" || $_SESSION['user']['rank']=="Reseller")
			{
				$my_credits = $db->sql_query("SELECT user_id, credits FROM users WHERE user_id = '".$_SESSION['user']['id']."'");
				$my_row = $db->sql_fetchassoc($my_credits);
				$user_id_2 = $my_row['user_id'];
				$credits_2 = $my_row['credits'];
				$add_credits = $db->Sanitize($add_credits);
				if($credits_2 == 0)
				{
					$db->HandleError("Sorry! You don't have much Credits!");
					$values['response'] = 0;
				}else{	
					$sub_credits = $db->Sanitize($add_credits);
					$add_credits = $db->Sanitize($add_credits);
					$add_credits_2 = (int)$add_credits + (int)$row_add['credits'];
					if($add_credits > 0)
					{
						$category = $db->Sanitize($_POST['category']);

						if($category == 'add')
						{
							if($credits_2 < $add_credits)
							{
								$db->HandleError("Sorry! You don't have much Credits!");
								$values['response'] = 0;
							}else{
								$update = $db->sql_query("UPDATE users SET credits='".$db->SanitizeForSQL($add_credits_2)."' 
								WHERE user_id='".$db->SanitizeForSQL($get_code)."' AND user_name='".$db->SanitizeForSQL($get_secret)."'");
								if($update)
								{
									$db->sql_query("INSERT INTO credits_logs
									(credits_id, credits_id2, credits_username, credits_qty, credits_date, ipaddress)
									VALUES
									('".$_SESSION['user']['id']."',
									 '".$db->SanitizeForSQL($get_code)."',
									 '".$db->SanitizeForSQL($get_secret)."',
									 '+".$db->SanitizeForSQL($add_credits)."',
									 '".date('Y-m-d h:i:s')."',
									 '".$_SERVER['REMOTE_ADDR']."')
									");
									$db->sql_query("UPDATE users SET credits = credits - '".$sub_credits."' 
									WHERE user_id='".$db->SanitizeForSQL($user_id_2)."'");
									$db->HandleSuccess($add_credits ." Credits Successfully! Added to " .$row_add['user_name']);	
									$values['response'] = 1;
									$values['type'] = 1;
								}else{
									$db->HandleError($add_credits ." Credits Failed! Transaction...");
									$values['response'] = 0;
								}
							}
						}else
						if($category == 'secret mode')
						{
							if($client_credits < $sub_credits){
								$db->HandleError("Sorry! ". $add_credits ." Decreasing Credits Failed! Transaction...");
								$values['response'] = 0;
							}else{
								$update = $db->sql_query("UPDATE users SET credits=credits - '".$db->SanitizeForSQL($sub_credits)."' 
								WHERE user_id='".$db->SanitizeForSQL($get_code)."' AND user_name='".$db->SanitizeForSQL($get_secret)."'");
								if($update)
								{
									$db->sql_query("INSERT INTO credits_logs
									(credits_id, credits_id2, credits_username, credits_qty, credits_date, ipaddress)
									VALUES
									('".$_SESSION['user']['id']."',
									 '".$db->SanitizeForSQL($get_code)."',
									 '".$db->SanitizeForSQL($get_secret)."',
									 '-".$db->SanitizeForSQL($add_credits)."',
									 '".date('Y-m-d h:i:s')."',
									 '".$_SERVER['REMOTE_ADDR']."')
									");
									$db->sql_query("UPDATE users SET credits = credits + '".$sub_credits."' 
									WHERE user_id='".$db->SanitizeForSQL($user_id_2)."'");
									$db->HandleSuccess($add_credits ." Credits Successfully! Added to " .$row_add['user_name']);	
									$values['response'] = 1;
									$values['type'] = 0;
								}else{
									$db->HandleError($add_credits ." Credits Failed! Transaction...");
									$values['response'] = 0;
								}
							}
						}else{
							$db->HandleError('Sorry! the transaction is inavalid!..');
							$values['response'] = 0;
						}
					}
				}
			}
			else if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank']=="Administrator")
			{
				$add_credits = $db->Sanitize($add_credits);
				$add_credits_2 = (int)$add_credits + (int)$row_add['credits'];
				if($add_credits > 0)
				{
					if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank']=="Administrator")
					{
						$category = $db->Sanitize($_POST['category']);
						if($category == 'add')
						{
							$update = $db->sql_query("UPDATE users SET credits='".$db->SanitizeForSQL($add_credits_2)."' 
							WHERE user_id='".$db->SanitizeForSQL($get_code)."' AND user_name='".$db->SanitizeForSQL($get_secret)."'");
							if($update)
							{
								$db->sql_query("INSERT INTO credits_logs
										(credits_id, credits_id2, credits_username, credits_qty, credits_date, ipaddress)
										VALUES
										('".$_SESSION['user']['id']."',
										 '".$db->SanitizeForSQL($get_code)."',
										 '".$db->SanitizeForSQL($get_secret)."',
										 '+".$db->SanitizeForSQL($add_credits)."',
										 '".date('Y-m-d h:i:s')."',
										 '".$_SERVER['REMOTE_ADDR']."')
										");
								$db->HandleSuccess($add_credits ." Credits Successfully! Added to " .$row_add['user_name']);
								$values['response'] = 1;
								$values['type'] = 1;
							}else{
								$db->HandleError($add_credits ." Credits Failed! Transaction...");
								$values['response'] = 0;
							}
						}else
						if($category == 'substract'){
							$sub_credits_2 = trim($_POST['add_credits']);
							if($client_credits < $sub_credits_2){
								$db->HandleError("Sorry! ". $add_credits ." Decreasing Credits Failed! Transaction...");
							}else{
								$update = $db->sql_query("UPDATE users SET credits=credits-'".$db->SanitizeForSQL($sub_credits_2)."'
								WHERE user_id='".$db->SanitizeForSQL($get_code)."' AND user_name='".$db->SanitizeForSQL($get_secret)."'");
								if($update)
								{
									$db->sql_query("INSERT INTO credits_logs
											(credits_id, credits_id2, credits_username, credits_qty, credits_date, ipaddress)
											VALUES
											('".$_SESSION['user']['id']."',
											 '".$db->SanitizeForSQL($get_code)."',
											 '".$db->SanitizeForSQL($get_secret)."',
											 '-".$db->SanitizeForSQL($add_credits)."',
											 '".date('Y-m-d h:i:s')."',
											 '".$_SERVER['REMOTE_ADDR']."')
											");
									$db->HandleSuccess($sub_credits_2 ." Credits Successfully! Substract to " .$row_add['user_name']);
									$values['type'] = 0;
									$values['response'] = 1;
								}else{
									$db->HandleError($sub_credits_2 ." Credits Failed! Transaction...");
									$values['response'] = 0;
								}
							}
						}else{
							$db->HandleError('Sorry! the transaction is inavalid!..');
							$values['response'] = 0;
						}
					}
				}
			}
		}
		$values['suc'] = $db->GetSuccessMessage();
		$values['err'] = $db->GetErrorMessage();
	}
	
	echo json_encode($values);
}else{
	header("location: users.php?user=seller");
}
?>