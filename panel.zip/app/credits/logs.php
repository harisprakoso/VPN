<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
if($_SESSION['user']['id']== 1 
|| $_SESSION['user']['rank']=="Administrator" 
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"){
	
$data = array();
$values = array();
$query = $db->sql_query("SELECT * FROM credits_logs WHERE credits_id='".$_SESSION['user']['id']."'");
while($row = $db->sql_fetchassoc($query))
{
	$values['username'] = $row['credits_username'];
	$values['qty'] = $row['credits_qty'];
	$values['ipaddress'] = $row['ipaddress'];
	$values['date'] = date('F d, Y h:i:s', strtotime($row['credits_date']));
	array_push($data, $values);
}

echo json_encode($data);
	
}else{
	header("location: ".$db->base_url()."users.php?user=seller");
}
?>