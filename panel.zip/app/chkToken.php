<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './config/connection.php';

if(!isset($_SESSION['user'])){
}else{	
	$token_query = $db->sql_query("SELECT token FROM users WHERE user_id='".$_SESSION['user']['id']."'");
	$token_row = $db->sql_fetchassoc($token_query);
	if($token_row['token'] != $db->CSRFtoken())
	{
		echo "<script> alert('Opps! Sorry! Your Token is Expired!...'); location.assign('".$db->base_url()."logout.php'); </script>";		
	}
}
?>