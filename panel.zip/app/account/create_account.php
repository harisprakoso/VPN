<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
$valid = true;
	if(isset($_POST['submitted']))
	{
		$post_full_name = $db -> Sanitize($_POST['full_name']);
		$post_email = $db -> Sanitize($_POST['email']);
		$post_location = $db -> Sanitize($_POST['location']);
		$post_payment = $db -> Sanitize($_POST['payment']);
		$post_contact = $db -> Sanitize($_POST['contact']);
		$post_username =$db -> Sanitize($_POST['username']);
		$post_password =$db -> Sanitize($_POST['password']);
		$post_password_two =$db -> Sanitize($_POST['password_two']);

		$whitelist = array("gmail.com", "yahoo.com", "yahoo.com.ph", "live.com", "hotmail.com");
		$code = md5(time());
		$code = rand(0,999999999);
		
		if(empty($post_full_name)){
			$db->HandleError("Full Name is Empty!...");
			$valid = false;
		}
		
		if(empty($post_username))
		{
			$db->HandleError("Username is empty!...");
			$valid = false;
		}
		else if(preg_match('/[^_a-z-A-Z-0-9-. ]/', $post_username))
		{
			$db->HandleError("Invalid Username!!...");
			$valid = false;
		}
		else
		{
			$username_chk = $db->sql_query("SELECT user_name FROM users WHERE user_name='".$db->SanitizeForSQL($post_username)."'");
			$username_chk = $db->sql_numrows($username_chk);
			if($username_chk > 0){
				$db->HandleError($post_username.' is already taken!');
				$valid = false;
			}
		}
		
		if($_SESSION['user']['id'] == 1	
			|| $_SESSION['user']['rank'] == "Administrator"
			|| $_SESSION['user']['rank']=="Sub Administrator"
			|| $_SESSION['user']['rank']=="Reseller"
			|| $_SESSION['user']['rank']=="Sub Reseller"){
			if(empty($post_email))
			{
				$db->HandleError("Email is Empty!...");
				$valid = false;
			}
			else if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/i", $post_email))
			{
				$db->HandleError("Invalid Email address!");
				$valid = false;
			}
			else
			{
				$email_chk = $db->select_row("SELECT user_email FROM users WHERE user_email='".$db->SanitizeForSQL($post_email)."'");
				$email_chk = $db->sql_numrows($email_chk);
				if($email_chk > 0){
					$db->HandleError($post_email." is already registered!");
					$valid = false;
				}
			}
		}else{
			if(empty($post_email))
			{
				$db->HandleError("Email is Empty!...");
				$valid = false;
			}
			else
			if (filter_var($post_email, FILTER_VALIDATE_EMAIL))
			{
				$explodedEmail = explode('@', $post_email);
				$domain = array_pop($explodedEmail);

				if(!in_array($domain, $whitelist))
				{
					$db->HandleError("Invalid Email address! Accepted Email List gmail.com, yahoo.com | .ph, live.com and hotmail.com'");
					$valid = false;
				}
			}
			else if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/i", $post_email))
			{
				$db->HandleError("Invalid Email address!");
				$valid = false;
			}
			else
			{
				$email_chk = $db->select_row("SELECT user_email FROM users WHERE user_email='".$db->SanitizeForSQL($post_email)."'");
				$email_chk = $db->sql_numrows($email_chk);
				if($email_chk > 0){
					$db->HandleError($post_email." is already registered!");
					$valid = false;
				}
			}
		}
		
		if(empty($post_password))
		{
			$db->HandleError("Password is empty!");
			$valid = false;
		}
		else if(strlen($post_password)<8)
		{
			$db->HandleError("Yor Password is too short!");
			$valid = false;
		}
		
		if(empty($post_password_two))
		{
			$db->HandleError("Retype password!");
			$valid = false;
		}
		else if(strlen($post_password_two)<8)
		{
			$db->HandleError("Yor Password is too short!");
			$valid = false;
		}
		
		if((!empty($post_password)) && (!empty($post_password_two)))
		{
			if($post_password != $post_password_two)
			{
				$db->HandleError('Password doesn\'t match!');
				$valid = false;
			}
		}
		
		$user_pass = $db->encrypt_key($db->encryptor('encrypt',$post_password));
		$auth_vpn = md5($post_password);
		if(isset($_SESSION['user'])){
			if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator"){
				if(isset($_POST['type'])){
					$type = $db->encryptor('decrypt', $_POST['type']);
					if($type==4){
						$set_type="4";
					}elseif($type==3){
						$set_type="3";
					}elseif($type==2){
						$set_type="2";
					}elseif($type==1){
						$set_type="1";
					}elseif($type==0){
						$set_type="0";
					}else{
						$db->HandleError("Invalid Transaction!...");
						$valid = false;
					}
				}
			}
			
			if($_SESSION['user']['rank']=="Sub Administrator"){
				if(isset($_POST['type'])){
					$type = $db->encryptor('decrypt', $_POST['type']);
					if($type==2){
						$set_type="2";
					}elseif($type==0){
						$set_type="0";
					}else{
						$db->HandleError("Invalid Transaction!...");
						$valid = false;
					}
				}
			}
			
			if($_SESSION['user']['rank']=="Reseller"){
				if(isset($_POST['type'])){
					$type = $db->encryptor('decrypt', $_POST['type']);
					if($type==1){
						$set_type="1";
					}elseif($type==0){
						$set_type="0";
					}else{
						$db->HandleError("Invalid Transaction!...");
						$valid = false;
					}
				}
			}
			
			if($_SESSION['user']['rank']=="Sub Reseller"){
				if(isset($_POST['type'])){
					$type = $db->encryptor('decrypt', $_POST['type']);
					if($type==0){
						$set_type="0";
					}else{
						$db->HandleError("Invalid Transaction!...");
						$valid = false;
					}
				}
			}
			if($_SESSION['user']['id'] == 1
			|| $_SESSION['user']['rank']=="Administrator"
			|| $_SESSION['user']['rank']=="Sub Administrator"
			|| $_SESSION['user']['rank']=="Reseller"
			|| $_SESSION['user']['rank']=="Sub Reseller"){
				if($valid)
				{                                                                           
					$query="INSERT INTO users
					(user_name, user_pass, auth_vpn, auth_ssl, user_email, full_name, 
					regdate, is_active, code, is_validated, duration, 
					is_reseller, upline, location, payment, contact)
					VALUES
					('".$db->SanitizeForSQL($post_username)."','".$db->SanitizeForSQL($user_pass)."','".$db->SanitizeForSQL($auth_vpn)."','".$db->SanitizeForSQL($post_password)."','".$db->SanitizeForSQL($post_email)."','".$db->SanitizeForSQL($post_full_name)."',
					NOW(),1,'".$db->SanitizeForSQL($code)."',1,7200,
					'".$set_type."',".$_SESSION['user']['id'].",'".$db->SanitizeForSQL($post_location)."','".$db->SanitizeForSQL($post_payment)."','".$db->SanitizeForSQL($post_contact)."')
					";
					$qry = $db -> sql_query($query);
					if($qry){
						$db->HandleSuccess("User Created.");
						$valid = true;
					}else{
						$db->HandleError("Failed to Register.");
						$valid = false;
					}
				}
			}
		}else{
			if($valid)
			{
				$set_type="0";
				$query="INSERT INTO users
				(user_name, user_pass, auth_vpn, auth_ssl, user_email, full_name, 
				regdate, is_active, code, is_validated, duration, 
				is_reseller, upline, location, payment, contact)
				VALUES
				('".$db->SanitizeForSQL($post_username)."','".$db->SanitizeForSQL($user_pass)."','".$db->SanitizeForSQL($auth_vpn)."','".$db->SanitizeForSQL($post_password)."','".$db->SanitizeForSQL($post_email)."','".$db->SanitizeForSQL($post_full_name)."',
				NOW(),1,'".$db->SanitizeForSQL($code)."',1,7200,
				'".$set_type."',1,'".$db->SanitizeForSQL($post_location)."','".$db->SanitizeForSQL($post_payment)."','".$db->SanitizeForSQL($post_contact)."')
				";
				$qry = $db -> sql_query($query);
				if($qry){
					$db->HandleSuccess("User Created.");
					$valid = true;
				}else{
					$db->HandleError("Failed to Register.");
					$valid = false;
				}
			}
		}
	
	}else{
		$db->HandleError(" Invalid Request. Please try again.");
		$valid = false;
	}

echo $db->GetSuccessMessage();
echo $db->GetErrorMessage();
?>