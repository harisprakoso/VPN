<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
$valid = true;

if(isset($_POST['submitted'])  == 'Changepwd Submit')
{
	$post_current = $db->Sanitize($_POST['current']);
	$post_current = $db->encrypt_key($db->encryptor('encrypt',$post_current));
	
	$post_password = $db->Sanitize($_POST['password']);
	$post_password_two = $db->Sanitize($_POST['password_two']);
	$auth_ssl = $_POST['password'];
	$post_user_id =$db->Sanitize($_POST['user_id']);
	
	$user_pass = $db->encrypt_key($db->encryptor('encrypt',$post_password));
	$auth_vpn = md5($post_password);
	
	$chk_auth_ssl = $db->sql_query("SELECT auth_ssl FROM users WHERE user_id='".$post_user_id."'");
	$chk_old_auth_ssl = $db->sql_fetchassoc($chk_auth_ssl);
	
	$chk_old = $db->sql_query("SELECT user_pass FROM users WHERE user_id='".$post_user_id."'");
	$old_pass = $db->sql_fetchassoc($chk_old);
	
	if(empty($post_current))
	{
		$db->HandleError("Current Password is empty!");
		$valid = false;
	}
	
	if(empty($post_password))
	{
		$db->HandleError("Password is empty!");
		$valid = false;
	}
	else if(strlen($post_password)<8)
	{
		$db->HandleError("Yor Password is too short!");
		$valid = false;
	}
		
	if(empty($post_password_two))
	{
		$db->HandleError("Retype password!");
		$valid = false;
	}
	else if(strlen($post_password_two)<8)
	{
		$db->HandleError("Yor Password is too short!");
		$valid = false;
	}
		
	if((!empty($post_password)) && (!empty($post_password_two)))
	{
		if($post_password != $post_password_two)
		{
			$db->HandleError('Password doesn\'t match!');
			$valid = false;
		}
	}
	
	if($post_current != $old_pass['user_pass'])
	{
		$db->HandleError('Corrent Password doesn\'t match!');
		$valid = false;
	}
	
	if($_SESSION['user']['id'] == $post_user_id 
	|| $db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$post_user_id) == $_SESSION['user']['id'] 
	|| $_SESSION['user']['rank']=="Administrator"
	|| $_SESSION['user']['rank']=="Sub Administrator"
	|| $_SESSION['user']['rank']=="Reseller"
	|| $_SESSION['user']['rank']=="Sub Reseller"){
		if($valid)
		{
			$query="UPDATE users SET
			user_pass='".$db->SanitizeForSQL($user_pass)."',
			auth_vpn='".$db->SanitizeForSQL($auth_vpn)."'
			WHERE
			user_id='".$post_user_id."'";
			
			if($chk_old_auth_ssl != null){
        		    $query2="UPDATE users SET
        		auth_ssl='".$db->SanitizeForSQL($auth_ssl)."' 
        		WHERE
        		user_id='".$post_user_id."'";
			}
			
            $qry2 = $db -> sql_query($query2);
            if($qry2){
				$db->HandleSuccess("SSL Updated");
				$valid = true;
			}else{
				$db->HandleError("Failed to Update SSL Authentication");
				$valid = false;
			}
			$qry = $db -> sql_query($query);
			if($qry){
				$db->HandleSuccess("User Successfully Changing Password.");
				$valid = true;
			}else{
				$db->HandleError("Failed to Change Password.");
				$valid = false;
			}
		}
	}
}else{
	$db->HandleError(" Invalid Request. Please try again.");
	$valid = false;
}

echo $db->GetSuccessMessage();
echo $db->GetErrorMessage();
?>