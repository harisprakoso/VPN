<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
include_once("../../config/connection.php");
$valid = true;

if(isset($_POST['submitted'])  == 'Edit Account')
{
	$post_full_name = $db->Sanitize($_POST['full_name']);
	$post_email = $db->Sanitize($_POST['email']);
	$post_location = $db->Sanitize($_POST['location']);
	$post_payment = $db->Sanitize($_POST['payment']);
	$post_contact = $db->Sanitize($_POST['contact']);
	$post_user_id = $db->Sanitize($_POST['user_id']);

	if(!isset($_SESSION['user'])){
		$db->HandleError("Invalid User!");
		$valid = false;
	}	

	if(empty($post_full_name)){
		$db->HandleError("Full Name is Empty!...");
		$valid = false;
	}
	
	if(empty($post_email))
	{
		$db->HandleError("Email is Empty!...");
		$valid = false;
	}
	else if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/i", $post_email))
	{
		$db->HandleError("Invalid Email address!");
		$valid = false;
	}
	else
	{
		$email_chk = $db->select_row("SELECT user_email FROM users WHERE user_email='".$db->SanitizeForSQL($post_email)."'");
		$email_chk = $db->sql_numrows($email_chk);
		if($email_chk > 0){
			$db->HandleError($post_email." is already registered!");
			$valid = false;
		}
	}
	
	if(isset($_SESSION['user']))
	{
		if($_SESSION['user']['id'] != $post_user_id)
		{
			if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank']=="Administrator"){
				if(isset($_POST['type'])){
					$type = $db->encryptor('decrypt', $_POST['type']);
					if($type==4){
						$set_type="4";
					}elseif($type==3){
						$set_type="3";
					}elseif($type==2){
						$set_type="2";
					}elseif($type==1){
						$set_type="1";
					}elseif($type==0){
						$set_type="0";
					}else{
						$db->HandleError("Invalid Transaction!...");
						$valid = false;
					}
				}
			}
				
			if($_SESSION['user']['rank']=="Sub Administrator"){
				if(isset($_POST['type'])){
					$type = $db->encryptor('decrypt', $_POST['type']);
					if($type==2){
						$set_type="2";
					}elseif($type==0){
						$set_type="0";
					}else{
						$db->HandleError("Invalid Transaction!...");
						$valid = false;
					}
				}
			}
				
			if($_SESSION['user']['rank']=="Reseller"){
				if(isset($_POST['type'])){
					$type = $db->encryptor('decrypt', $_POST['type']);
					if($type==1){
						$set_type="1";
					}elseif($type==0){
						$set_type="0";
					}else{
						$db->HandleError("Invalid Transaction!...");
						$valid = false;
					}
				}
			}
				
			if($_SESSION['user']['rank']=="Sub Reseller"){
				if(isset($_POST['type'])){
					$type = $db->encryptor('decrypt', $_POST['type']);
					if($type==0){
						$set_type="0";
					}else{
						$db->HandleError("Invalid Transaction!...");
						$valid = false;
					}
				}
			}
		}else{
			$chk_acct = $db->sql_query("SELECT is_reseller FROM users WHERE user_id='".$post_user_id."'");
			$acct_row = $db->sql_fetchassoc($chk_acct);
			$set_type = $acct_row['is_reseller'];
		}

		if($_SESSION['user']['id'] == $post_user_id 
		|| $db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$post_user_id) == $_SESSION['user']['id'] 
		|| $_SESSION['user']['rank']=="Administrator"
		|| $_SESSION['user']['rank']=="Sub Administrator"
		|| $_SESSION['user']['rank']=="Reseller"
		|| $_SESSION['user']['rank']=="Sub Reseller")
		{
			if($valid)
			{
				if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank']=="Administrator")
				{
					$upline = $db->Sanitize($_POST['upline']);
					$query="UPDATE users SET
					full_name='".$db->SanitizeForSQL($post_full_name)."', user_email='".$db->SanitizeForSQL($post_email)."', 
					location='".$db->SanitizeForSQL($post_location)."', payment='".$db->SanitizeForSQL($post_payment)."', 
					is_reseller='".$db->SanitizeForSQL($set_type)."', contact='".$db->SanitizeForSQL($post_contact)."',
					upline='".$db->SanitizeForSQL($upline)."'
					WHERE
					user_id = '".$post_user_id."'";
					$qry = $db -> sql_query($query);
					if($qry){
						$db->HandleSuccess("User Successfully Updated.");
						$valid = true;
					}else{
						$db->HandleError("Failed to Update.");
						$valid = false;
					}
				}else{
					$query="UPDATE users SET
					full_name='".$db->SanitizeForSQL($post_full_name)."', user_email='".$db->SanitizeForSQL($post_email)."', 
					location='".$db->SanitizeForSQL($post_location)."', payment='".$db->SanitizeForSQL($post_payment)."', 
					is_reseller='".$db->SanitizeForSQL($set_type)."', contact='".$db->SanitizeForSQL($post_contact)."'
					WHERE
					user_id = '".$post_user_id."'";
					$qry = $db -> sql_query($query);
					if($qry){
						$db->HandleSuccess("User Successfully Updated.");
						$valid = true;
					}else{
						$db->HandleError("Failed to Update.");
						$valid = false;
					}

				}
			}
		}
	}
}else{
	$db->HandleError(" Invalid Request. Please try again.");
	$valid = false;
}

echo $db->GetSuccessMessage();
echo $db->GetErrorMessage();
?>