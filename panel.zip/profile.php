<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
?>
<!DOCTYPE html>
<html>

<?php
require DOC_ROOT_PATH . './components/header.php';
?>
<body>
<?php
require DOC_ROOT_PATH . './app/chkToken.php';
require DOC_ROOT_PATH . './components/nav.php';
require DOC_ROOT_PATH . './components/sidebar.php';

if(!isset($_SESSION['user'])){
	header("location: login.php");
}
$get_id=0;
if(isset($_GET['user'])){
	$get_id = $db -> escape($_GET['user']);
	if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){
		header("location: profile.php");
	}
}else{
	$get_id = $current_uid;
}

	$profile_query = $db->sql_query("SELECT * FROM `users` WHERE `user_id`=$get_id");
	$profile_info = $db->sql_fetchassoc($profile_query);

	$dur = $db->calc_time($profile_info['duration']);

	$duration = $dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minute(s)";

	$dur2 = $db->calc_time($profile_info['vip_duration']);

	$vip_duration = $dur2['days'] . " day(s), " . $dur2['hours'] . " hour(s) and " . $dur2['minutes'] . " minute(s)";
	
	$date = date_create(date('Y-m-d H:i:s'));
	
    $ssh_user = substr(base_convert(md5($profile_info['user_name']), 16,32), 0, 6);
    if($profile_info['auth_ssl'] == 1){
        
        if($profile_info['duration'] < 1 && $profile_info['vip_duration'] < 1){
	        $ssl_status = "NOT ACTIVE";
	        $ssl_user = "Must have Current Duration";
    	}else{
    	    $ssl_status = "NEED ACTIONS";
            $ssl_user = "Please Update Password to Activate SSH account";
	    }
        
    }else{
        
        if($profile_info['duration'] < 1 && $profile_info['vip_duration'] < 1){
	        $ssl_status = "NOT ACTIVE";
	        $ssl_user = "Must have Current VIP Duration";
    	}else{
    	    $ssl_status = "ACTIVATED";
    	    $ssl_user = "Username: ".$ssh_user;
	    }
    }
	
	
	
	$pdays = $dur['days'] . " days";
	$phours = $dur['hours'] . " hours";
	$pminutes = $dur['minutes'] . " minutes";
	$pseconds = $dur['seconds'] . " seconds";
	if($profile_info['duration'] == 0){
		$premium_expiration = "<font color='red'>Not Active</font>";
	}else{
		$premuim_duration = strtotime($pdays . $phours . $pminutes . $pseconds);
		$premium_expiration = date('F d, Y h:i:s A', $premuim_duration);
	}
				
	$vdays = $dur2['days'] . " days";
	$vhours = $dur2['hours'] . " hours";
    $vminutes = $dur2['minutes'] . " minutes";
	$vseconds = $dur2['seconds'] . " seconds";
	if($profile_info['vip_duration'] == 0){
		$vip_expiration = "<font color='red'>Not Active</font>";	
	}else{
		$vip_duration = strtotime($vdays . $vhours . $vminutes . $vseconds);
		$vip_expiration = date('F d, Y h:i:s A', $vip_duration);
	}
	
/*	
	date_add($date, date_interval_create_from_date_string($profile_info['duration'].' seconds'));
	$premium_expiration = date_format($date, 'm/d')."/".substr(date_format($date, 'Y'),2,2);

	date_add($date, date_interval_create_from_date_string($profile_info['vip_duration'].' seconds'));
	$vip_expiration = date_format($date, 'm/d')."/".substr(date_format($date, 'Y'),2,2);
*/	
	
	
	
	$premium_status="Active";
	if($profile_info['duration']==0){
		$premium_status="Inactive";
		//$premium_expiration="--";
	}
	
	$vip_status="Active";
	if($profile_info['vip_duration']==0){
		$vip_status="Inactive";
		//$vip_expiration="--";
	}
	
	$user_rank="";
	if($profile_info['is_reseller']==4){
		$user_rank="Administrator";
	}elseif($profile_info['is_reseller']==3){
		$user_rank="Sub Administrator";
	}elseif($profile_info['is_reseller']==2){
		$user_rank="Reseller";
	}elseif($profile_info['is_reseller']==1){
		$user_rank="Sub Reseller";
	}else{
		$user_rank="Client";
	}
	if($get_id==1){
		$user_rank="Administrator";
	}
	$is_suspend = "";
	if($profile_info['is_suspend']==0 && $profile_info['is_ban']==0)
	{
		if($_SESSION['user']['id'] != $get_id){
			if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator")
			{
				$is_suspend .= '<a href="javascript:void(0)" onclick="unbanned('.$get_id.')">Banned</a>';
			}else{
				$is_suspend .= 'Banned';
			}
		}else{
			$is_suspend .= 'Banned';
		}
	}elseif($profile_info['is_suspend']==0 && $profile_info['is_ban']==1)
	{
		if($_SESSION['user']['id'] != $get_id){
			$is_suspend .= '<a href="javascript:void(0)" onclick="unsuspend('.$get_id.')">Suspended</a>';
		}else{
			$is_suspend .= 'Suspended';
		}
	}elseif($profile_info['is_suspend']==1 && $profile_info['is_ban']==1)
	{
		$is_suspend .= 'Live';
	}
	
	$is_freeze = "";
	if($profile_info['is_freeze']==1)
	{
		$is_freeze .= 'Live';
	}else{
		if($_SESSION['user']['id'] != $get_id){
			$is_freeze .= '<a href="javascript:void(0)" onclick="unfreeze('.$get_id.')">Freezed</a>';
		}else{
			$is_freeze .= 'Freezed';
		}
	}
	
	$chk_upline = $db->sql_query("SELECT full_name FROM users WHERE user_id='".$profile_info['upline']."'");
	$upline_row = $db->sql_fetchassoc($chk_upline);
	
?>	
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-user"></span></a></li>
				<li class="active">View Account Page</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-blue panel-widget ">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-shopping-cart glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="medium"><strong><?php echo $profile_info['credits'];?></strong></div>
							<div class="text-muted">Credits</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-star glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="medium"><strong><?php echo $premium_status;?></strong></div>
							<div class="text-muted">Premium</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-red panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-time glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="small"><strong><?php echo $premium_expiration;?></strong></div>
							<div class="text-muted">Expiration</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-star glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="small"><?php echo $vip_status;?></div>
							<div class="text-muted">VIP</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-red panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-time glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="medium"><?php echo $vip_expiration;?></div>
							<div class="text-muted">Expiration</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-user glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="medium"><strong><?php echo $user_rank;?></strong></div>
							<div class="text-muted">User Type</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-user glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="medium"><strong><?php echo $is_suspend;?></strong></div>
							<div class="text-muted">Suspend Status</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<em class="glyphicon glyphicon-user glyphicon-l"></em>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="medium"><strong><?php echo $is_freeze;?></strong></div>
							<div class="text-muted">Freeze Status</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div id="success"></div>
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Account Info</div>
					<div class="panel-body">
						<div class="col-md-6">
							<div class="form-group">
								<label>Full Name</label>
								<input class="form-control" readonly value="<?php echo htmlspecialchars($profile_info['full_name']);?>">
							</div>

							<div class="form-group">
								<label>Email</label>
								<input class="form-control" type="email" readonly value="<?php echo htmlspecialchars($profile_info['user_email']);?>">
							</div>

							<div class="form-group">
								<label>Address</label>
								<input class="form-control" type="text" readonly value="<?php echo htmlspecialchars($profile_info['location']);?>">
							</div>

							<div class="form-group">
								<label>Mode of Payment (Reseller)</label>
								<input class="form-control" type="text" readonly value="<?php echo htmlspecialchars($profile_info['payment']);?>">
							</div>

							<div class="form-group">
								<label>Contact Info</label>
								<input class="form-control" type="text" readonly value="<?php echo htmlspecialchars($profile_info['contact']);?>">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Reseller</label>
								<input type="text" class="form-control" readonly value="<?php echo htmlspecialchars($upline_row['full_name']); ?>">
							</div>
							<div class="form-group">
								<label>Premium Duration</label>
								<input type="text" class="form-control" readonly value="<?php echo $duration; ?>">
							</div>
							<div class="form-group">
								<label>VIP Duration</label>
								<input type="text" class="form-control" readonly value="<?php echo $vip_duration; ?>">
							</div>
							<div class="form-group">
								<label>SSH Status</label>
								<input type="text" class="form-control" readonly value="<?php echo $ssl_status; ?>">
								<input type="text" class="form-control" readonly value="<?php echo $ssl_user; ?>">
							</div>
						</div>
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
	</div>	<!--/.main-->

<?php 
require DOC_ROOT_PATH . './components/js.php';
?>
<script>
<?php
if($_SESSION['user']['id'] != $get_id)
{
?>
function unsuspend(id){
	var confirmed = confirm("Are you sure?, do you really want to unsuspend this user?.");
	if(confirmed)
	{
		$.ajax({
			type: "POST",
			url: "app/users/unsuspend.php",
			data: "id="+id,
			success: function(data){
				$('#success').html(data);
			}
		});
	}
}

function unfreeze(id){
	var confirmed = confirm("Are you sure?, do you really want to unfreeze this user?.");
	if(confirmed)
	{
		$.ajax({
			type: "POST",
			url: "app/users/unfreeze.php",
			data: "id="+id,
			success: function(data){
				$('#success').html(data);
			}
		});
	}
}
<?php
	if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator")
	{
?>
function unbanned(id){
	var confirmed = confirm("Are you sure?, do you really want to unbanned this user?.");
	if(confirmed)
	{
		$.ajax({
			type: "POST",
			url: "app/users/unbanned.php",
			data: "id="+id,
			success: function(data){
				$('#success').html(data);
			}
		});
	}
}
<?php
	}
}
?>
</script>
</body>

</html>
