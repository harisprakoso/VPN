<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
?>
<!DOCTYPE html>
<html>

<?php
require DOC_ROOT_PATH . './components/header.php';
?>
<body>
<?php
require DOC_ROOT_PATH . './app/chkToken.php';
require DOC_ROOT_PATH . './components/nav.php';
require DOC_ROOT_PATH . './components/sidebar.php';

if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator" || $_SESSION['user']['rank']=="Sub Administrator"){}else{header("location: users.php?user=seller");}

?>	
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-list-alt"></span></a></li>
				<li class="active">Server Upload</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">All Servers</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="btn-group btn-group-justified" role="group">
					<div class="btn-group" role="group">
						<button type="button" class="btn btn-info" onclick="server_add()" id="server_add" >
							<i class="glyphicon glyphicon-plus"></i> &nbsp; Add Records
						</button>
					</div>
				</div>
				<div id="success"></div>
				<div class="panel panel-default">
					<div class="panel-heading">Server List</div>
					<div class="panel-body">
						<table id="servertbl" data-toggle="table" data-url="app/servers/list.php"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="chk[]" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						    <thead>
						    <tr>
						        <th class="text-center" data-field="server_name" data-sortable="true">Server</th>
						        <th class="text-center" data-field="server_ip"  data-sortable="true">IP Address</th>
						        <th class="text-center" data-field="server_category" data-sortable="true">Category</th>
						        <th class="text-center" data-field="server_port" data-sortable="true">Port</th>
								<th class="text-center" data-field="status" data-sortable="true">Status</th>
								<th class="text-center" data-field="action" data-sortable="true">Controls</th>
						    </tr>
						    </thead>
						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
		
	</div>	<!--/.main-->
	
	<div class="modal fade" id="modal_form" tabindex="-1" role="dialog" aria-labelledby="modal_form" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h3 class="modal-title"></h3>
				</div>
				<div class="modal-body">
					<form id="server_frm" name="server_frm">
						<input type="hidden" id="server_id" name="server_id">
						<input type="hidden" id="submitted" name="submitted" value="Server Upload">
						<div class="row">
							<div class="form-group control-group col-md-12">
								<div class="controls input-group">
									<label class="control-label input-group-addon" for="server_name">Server Name</label>
									<input class="form-control" id="server_name" name="server_name" placeholder="Server Name" />
								</div>
							</div>
							<div class="form-group control-group col-md-6">
								<div class="controls input-group">
									<label class="control-label input-group-addon" for="server_category">Server Category</label>
									<select class="form-control" id="server_category" name="server_category">
										<option value="premium" selected="selected">Premium Server</option>
										<option value="vip">VIP Server</option>
									</select>
								</div>
							</div>
							<div class="form-group control-group col-md-6">
								<div class="controls input-group">
									<label class="control-label input-group-addon" for="server_ip">Server IP</label>
									<input class="form-control" id="server_ip" name="server_ip" placeholder="IP Address" />
								</div>
							</div>
						</div>
						<div class="row">											
							<div class="form-group control-group col-md-4">
								<div class="controls input-group">
									<label class="control-label input-group-addon" for="server_port">Port</label>
									<input class="form-control" id="server_port" name="server_port" placeholder="Server Port" />
								</div>
							</div>
							<div class="form-group control-group col-md-4">
								<div class="controls input-group">
									<label class="control-label input-group-addon" for="server_folder">Folder</label>
									<input class="form-control" id="server_folder" name="server_folder" placeholder="Server Folder" />
								</div>
							</div>
							<div class="form-group control-group col-md-4">
								<div class="controls input-group">
									<label class="control-label input-group-addon" for="server_tcp">TCP</label>
									<input class="form-control" id="server_tcp" name="server_tcp" placeholder="Server TCP" />
								</div>
							</div>
							<div class="col-md-12 text-center">
								<div id="server_parser" class="form-control col-md-12"></div>
							</div>
						</div>
						<div class="control-group form-group">
							<div class="modal-footer">
								<button type="submit" id="submitServer" name="submitServer" class="btn btn-success">Server Upload</button>
								<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
								<span align="left" id="loading"></span>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php 
require DOC_ROOT_PATH . './components/js.php';
?>

	<script src="js/bootstrap-table.js"></script>
<script>
var save_method;

function server_add(){
    save_method = 'add';
    $('#server_frm')[0].reset();
	$('#server_frm').trigger('reset');
    $('.form-group').removeClass('has-error');
    $('.help-block').empty();
    $('#modal_form').modal('show');
	$('.modal-title').text('Server List Form');
	$('#submitServer').html("Server Upload");
	$('#submitted').val("Server Upload");
	$('#server_parser').html('');
}

function delete_records(id) 
{
	var confirmed = confirm("Are you sure?, do you want to delete?.");
	if(confirmed)
	{
		$.ajax({
			type: "POST",
			url: "app/servers/server_delete.php",
			data: "server_id="+id,
			cache: false,
			success: function(data) {
				$('#success').html(data);
				$('button[name="refresh"]').trigger('click');
			},
			error: function(data) {
				$('#success').html(data);
			}
		});
	}
}

function edit(id){
	save_method = 'update';
	$('#server_frm').trigger('reset');
	$('#submitted').val("Server Edit");
	$('.form-group').removeClass('has-error');
	$('.help-block').empty();
	$.ajax({
		url : "app/servers/server_edit.php",
		data: "server_id="+id,
		type: "GET",		
		dataType: "JSON",
		cache: false,
		success: function(data)
		{
			$('#server_id').val(data.server_id);
			$('#server_name').val(data.server_name);
			$('#server_category').val(data.server_category);
			$('#server_ip').val(data.server_ip);
			$('#server_port').val(data.server_port);
			$('#server_folder').val(data.server_folder);
			$('#server_tcp').val(data.server_tcp);
			$('#server_parser').html(data.server_parser);
			$('#modal_form').modal('show');
			$('.modal-title').text('Edit Server List Form: ' +data.server_name);
		},
		error: function (jqXHR, textStatus, errorThrown)
		{
			alert('Error get data from ajax');
		}
	});
}

$('document').ready(function()
{
	var $form  = $("#server_frm");
	$form.ajaxForm({
		url: "app/servers/server_upload.php",
		data: $form.serialize(), 
		type: "POST",
		cache: false,
		error: function(jqXHR, textStatus, errorThrown) {
			$('#success').html(data);
			$form[0].reset();
			$('#modal_form').modal('hide');
		},
		success: function (result)
		{
			$('#success').html(result);
			$form[0].reset();
			$('button[name="refresh"]').trigger('click');
			$('#modal_form').modal('hide');
			setTimeout(function () { $('.close').trigger('click'); }, 3000);
		}
	});
	
	$('#server_ip').on('input', function (event){
		this.value = this.value.replace(/[^0-9-.]/g, '');
	});
	$('#server_port').on('input', function (event){
		this.value = this.value.replace(/[^0-9]/g, '');
	});
});
</script>
</body>

</html>
