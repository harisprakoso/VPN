<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
?>
<!DOCTYPE html>
<html>

<?php
require DOC_ROOT_PATH . './components/header.php';
?>
<body>
<?php
require DOC_ROOT_PATH . './app/chkToken.php';
require DOC_ROOT_PATH . './components/nav.php';
require DOC_ROOT_PATH . './components/sidebar.php';

if(!isset($_SESSION['user'])){
	header("location: users.php?user=reseller");
}
?>	
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-list-alt"></span></a></li>
				<li class="active">Online Users</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">All Users Online</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Online List</div>
					<div class="panel-body">
						<table id="servertbl" data-toggle="table" data-url="app/servers/onlineusers.php"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="chk[]" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						    <thead>
						    <tr>
						        <th class="text-center" data-field="CommonName" data-sortable="true">Username</th>
								<?php
								if($_SESSION['user']['id']== 1 || $_SESSION['user']['rank']=="Administrator" || $_SESSION['user']['rank']=="Sub Administrator"){
						        echo '<th class="text-center" data-field="RealAddress"  data-sortable="true">IP Address</th>';
								}
								?>
						        <th class="text-center" data-field="BytesReceived" data-sortable="true">Received</th>
						        <th class="text-center" data-field="BytesSent" data-sortable="true">Sent</th>
								<th class="text-center" data-field="Since" data-sortable="true">Date Connected</th>
								<th class="text-center" data-field="server_name" data-sortable="true">Server</th>
						    </tr>
						    </thead>
						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
		
	</div>	<!--/.main-->

<?php 
require DOC_ROOT_PATH . './components/js.php';
?>

	<script src="js/bootstrap-table.js"></script>
</body>

</html>
