<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
?>
<!DOCTYPE html>
<html>

<?php
require DOC_ROOT_PATH . './components/header.php';
?>
<body>
<?php
require DOC_ROOT_PATH . './app/chkToken.php';
require DOC_ROOT_PATH . './components/nav.php';
require DOC_ROOT_PATH . './components/sidebar.php';

if(!isset($_SESSION['user'])){
	header("location: login.php");
}


$get_id=0;
if($_SESSION['user']['id'] == 1 
|| $_SESSION['user']['rank']=="Administrator"
|| $_SESSION['user']['rank']=="Sub Administrator"
|| $_SESSION['user']['rank']=="Reseller"){
	if(isset($_GET['user'])){
		$get_id = $db -> escape($_GET['user']);
		if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){
			header("location: account.php");
		}else{
			if($db -> select("SELECT `upline` FROM `users` WHERE `user_id`=$get_id") <> $_SESSION['user']['id'] && $current_rank <> "Administrator"){
				header("location: account.php");
			}
		}
	}else{
		$get_id = $current_uid;
	}
}else{
	header("location: account.php");
}
$profile_info = $db -> select_row("SELECT * FROM `users` WHERE `user_id`=$get_id");
$get_secret = $db->encryptor('encrypt', $profile_info[0]['user_name']);
$get_secret = $db->encryptor('encrypt', $get_secret);
$get_code = $db->encryptor('encrypt', $get_id);
$get_code = $db->encryptor('encrypt', $get_code);

$add_encrypt = $db->encryptor('encrypt', 'add');
$sub_encrypt = $db->encryptor('encrypt', 'substract');
?>	
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-usd"></span></a></li>
				<li class="active">Credits Management</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Manage Credits</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Credits Management Form</div>
					<div class="panel-body">
							<div class="col-md-6">
								<div class="form-group">
									<label>Full Name</label>
									<input class="form-control" placeholder="Enter Full Name" name="full_name" value="<?php echo htmlspecialchars($profile_info[0]['full_name']);?>" readonly>
								</div>
								
								<div class="form-group">
									<label>Email</label>
									<input class="form-control" type="email" name="email" placeholder="email@example.com" value="<?php echo htmlspecialchars($profile_info[0]['user_email']);?>" readonly>
								</div>
								<div class="form-group">
									<label>Location</label>
									<input class="form-control" placeholder="Enter Location" name="location" value="<?php echo htmlspecialchars($profile_info[0]['location']);?>" readonly>
								</div>
								<div class="form-group">
									<label>Mode of Payment (Reseller)</label>
									<input class="form-control" placeholder="For Resellers" name="payment" value="<?php echo htmlspecialchars($profile_info[0]['payment']);?>" readonly>
								</div>
								<div class="form-group">
									<label>Contact Info</label>
									<input class="form-control" placeholder="Contact Info" name="contact" value="<?php echo htmlspecialchars($profile_info[0]['contact']);?>" readonly>
								</div>
								<!--button type="submit" class="btn btn-primary">Update Profile</button-->
							</div>
							<div class="col-md-6">
								<?php

									if($_SESSION['user']['rank']=="Sub Administrator" && $_SESSION['user']['id']==$get_id
									|| $_SESSION['user']['rank']=="Reseller" && $_SESSION['user']['id']==$get_id)
									{
								?>
									<div class="form-control">Credits: <?php echo htmlspecialchars($profile_info[0]['credits']);?></div>
								<?php
									}else{
								?>
								<form id="credits_form" role="form">
									<input type="hidden" name="submitted" value="Credits Submitted" >
									<input type="hidden" name="user_id" value="<?php echo $get_id;?>" >
									<div class="form-group">
										<label>Current Credits</label>
										<input type="number" id="current_credits" class="form-control" value="<?php echo htmlspecialchars($profile_info[0]['credits']);?>" readonly>
									</div>
									
									<div class="form-group">
										<label>Credits Amount:</label>
										<input id="add_credits" class="form-control" name="add_credits" type="number" placeholder="Amount" required>
									</div>
									
									<input type="hidden" id="code" name="code" value="<?php echo $get_code; ?>" />
									<input type="hidden" id="secret" name="secret" value="<?php echo $get_secret; ?>" />
									<?php
									if($_SESSION['user']['id'] == 1 && $_SESSION['user']['id']==$get_id || $_SESSION['user']['rank']=="Administrator" && $_SESSION['user']['id']==$get_id)
									{
										echo '<input type="hidden" id="category" name="category" value="add" />';
									}else{
										if($_SESSION['user']['id'] == 1 || $_SESSION['user']['rank']=="Administrator")
										{
											echo '
											<div class="form-group">
												<label>Choose Category</label>
												<select class="form-control" name="category">
													<option value="add">Add Credits</option>
													<option value="substract">Substract Credits</option>
												</select>
											</div>';
										}else{
											echo '<input type="hidden" id="category" name="category" value="add" />';
										}
									}
									?>
									<button type="submit" class="btn btn-primary">Submit Credits</button>
									<br /><br />
									<div class="alert bg-primary" role="alert" id="error-alert" style="display:none;">
										<span class="glyphicon glyphicon-exclamation-sign"></span><span id="alert-message"> </span></a>
									</div>
								</form>
								<?php
									}
								?>
								<div id="success"></div>
							</div>
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h1 class="text-center">Credits Logs</h1>
					</div>
					<div class="panel-body">
						<table data-toggle="table" data-url="app/credits/logs.php"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="chk[]" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						    <thead>
						    <tr>
						        <th class="text-center" data-field="username" data-sortable="true">Username</th>
						        <th class="text-center" data-field="qty"  data-sortable="true">Quantity</th>
						        <th class="text-center" data-field="ipaddress" data-sortable="true">IP</th>
						        <th class="text-center" data-field="date" data-sortable="true">Date</th>
						    </tr>
						    </thead>
						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
		
	</div>	<!--/.main-->

<?php 
require DOC_ROOT_PATH . './components/js.php';
?>
<script src="js/bootstrap-table.js"></script>
<script>
$('document').ready(function(){
	var $credits_form  = $("#credits_form");
	$credits_form.ajaxForm({
		type: "POST",
		url: "app/credits/add_credits.php", 
		data: $credits_form.serialize(), 
		dataType: "JSON",
		cache: false,
		success: function (result)
		{
			if(result.response == 0)
			{
				$('#success').html(result.err);
			}else{
				$('#success').html(result.suc);
				if(result.type == 1)
				{
					$('#current_credits').val(parseInt($('#current_credits').val())+parseInt($('#add_credits').val()));
				}else{
					$('#current_credits').val(parseInt($('#current_credits').val())-parseInt($('#add_credits').val()));
				}
				
			}

			$('#add_credits').val('');
			setTimeout(function () {
				$('.close').trigger('click');
			}, 3000);
		}
	});
});
</script>
	
</body>

</html>
