<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
?>
<!DOCTYPE html>
<html>

<?php
require DOC_ROOT_PATH . './components/header.php';
?>
<body>
<?php
require DOC_ROOT_PATH . './app/chkToken.php';
require DOC_ROOT_PATH . './components/nav.php';
require DOC_ROOT_PATH . './components/sidebar.php';

$delete_message="";
$get_type="";
if(isset($_GET['user'])){
	switch($db -> escape($_GET['user'])){
		case "seller":
			$get_type="?user=seller";
			break;
		case "subadmin":
			$get_type="?user=subadmin";
			if($current_rank=="Sub Administrator" 
			|| $current_rank=="Reseller" 
			|| $current_rank=="Sub Reseller"
			|| $current_rank=="Client"){
				header("location: users.php?user=seller");
			}
			break;
		case "reseller":
			if($current_rank=="Reseller" 
			|| $current_rank=="Sub Reseller"
			|| $current_rank=="Client"){
				header("location: users.php?user=seller");
			}

			$get_type="?user=reseller";
			break;
		case "subreseller":
			if($current_rank=="Sub Reseller"
			|| $current_rank=="Client"){
				header("location: users.php?user=seller");
			}

			$get_type="?user=subreseller";
			break;
		case "client":
			if($current_rank=="Administrator" 
			|| $current_rank=="Sub Administrator"
			|| $current_rank=="Reseller"
			|| $current_rank=="Sub Reseller"){
			}else{
				header("location: users.php?user=seller");
			}
			$get_type="?user=client";
			break;
		case "all":
			if($current_rank<>"Administrator"){
				header("location: users.php?user=seller");
			}
		default:
			header("location: users.php?user=seller");
	}

	if(isset($_GET['delete'])){
		if($_GET['id']<>1){
			if($_GET['delete']==0){
				if( $db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$db -> escape($_GET['id'])) == $_SESSION['user']['id'] || $_SESSION['user']['rank']=="Administrator"){
					$db -> sql_query("DELETE FROM `users` WHERE `user_id`!=1 AND `user_id`=".$db -> escape($_GET['id']));
					if(isset($_GET['users'])){
						header("location: users.php?user=".$db -> escape($_GET['user'])."&delete=1");
					}else{
						header("location: users.php?delete=1");
					}
					
				}else{
					$delete_message="alert('Unauthorized Action.');";
				}
			}elseif($_GET['delete']==1){
				$delete_message="alert('User Deleted!');";
			}
		}else{
			$delete_message="alert('Action Denied!');";
		}
	}
}else{
	if($current_rank<>"Administrator"){
		header("location: users.php?user=reseller");
	}else{
		if(isset($_GET['delete'])){
			if($_GET['delete']==1){
				$delete_message="alert('User Deleted!');";
			}
		}
	}
}
?>	
	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-list-alt"></span></a></li>
				<li class="active">Users</li>
			</ol>
		</div><!--/.row-->
		<?php
		$users = "";
		if(isset($_GET['user'])){
			if($_GET['user']=="subadmin"){
				$users="Sub Administrator ";
			}elseif($_GET['user']=="reseller"){
				$users="Reseller ";
			}elseif($_GET['user']=="subreseller"){
				$users="Sub Reseller ";
			}elseif($_GET['user']=="client"){
				$users="Client ";
			}elseif($_GET['user']=="seller"){
				$users="Authorized Seller ";
			}else{
				$users="All ";
			}
		}else{
			$users="All ";
		}
		?>
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><?php echo $users;?>Users</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Users List</div>
					<div class="panel-body">
						<table data-toggle="table" data-url="app/users/list.php<?php echo $get_type;?>"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						    <thead>
						    <tr>
						        <?php
						        echo '<th data-field="user_name" data-sortable="true">Username</th>';
						        echo '<th data-field="full_name"  data-sortable="true">Name</th>';
						        echo '<th data-field="type" data-sortable="true">User Type</th>';
						        echo '<th data-field="premium_status" data-sortable="true">Premium Status</th>';
								if(isset($_GET['user'])){
									if($current_rank=="Administrator"
									|| $current_rank=="Sub Administrator"
									|| $current_rank=="Reseller"
									|| $current_rank=="Sub Reseller")
									{
										echo '<th data-field="duration" data-sortable="true">Premium</th>';
									}
								}else{
									echo '<th data-field="duration" data-sortable="true">Premium</th>';
								}
						        echo '<th data-field="vip_status" data-sortable="true">VIP Status</th>';
								if(isset($_GET['user'])){
									if($current_rank=="Administrator"
									|| $current_rank=="Sub Administrator"
									|| $current_rank=="Reseller"
									|| $current_rank=="Sub Reseller")
									{
										echo '<th data-field="vip_duration" data-sortable="true">VIP</th>';
									}
								}else{
									echo '<th data-field="vip_duration" data-sortable="true">VIP</th>';
								}
								if(isset($_GET['user'])){
									if($_GET['user']=="seller" || $_GET['user']=="subreseller" || $_GET['user']=="reseller" || $_GET['user']=="subadmin")
									{
										echo '<th data-field="credits" data-sortable="true">Credits</th>';
									}
								}
								echo '<th data-field="payment" data-sortable="true">Payment Method</th>';
						        echo '<th data-field="contact" data-sortable="true">Contact</th>';
								echo '<th data-field="stats" data-sortable="true">Status</th>';
								echo '<th data-field="login" data-sortable="true">Login</th>';
						        echo '<th data-field="action" data-sortable="true">Action</th>';
								?>
						    </tr>
						    </thead>
						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
		
	</div>	<!--/.main-->

<?php 
require DOC_ROOT_PATH . './components/js.php';
?>

	<script src="js/bootstrap-table.js"></script>
</body>
<script>
function view_profile(id){
	window.location="profile.php?user="+id;
}

function edit_user(id){
	window.location="account.php?user="+id;
}


function credit_user(id){
	window.location="credits.php?user="+id;
}

function monitor_user(id){
	window.location="clients.php?id="+id;
}

function delete_user(id){
	var r = confirm('Delete User?');
	if (r == true) { 
		window.location="users.php?user=client&id="+id+"&delete=0";
	}
}
setTimeout(function () { <?php echo $delete_message;?>}, 1000);
</script>
</html>
